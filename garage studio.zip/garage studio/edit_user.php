<?php
session_start();
require_once 'connection_cust.php'; // Include your database connection

// Check if the user is logged in and has appropriate access level
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 1) {
    header('Location: page_login.php');
    exit();
}

// Check if user ID is set in the URL
if (!isset($_GET['uUserID'])) {
    header('Location: users_audit.php');
    exit();
}

$uUserID = $_GET['uUserID'];
$uFName = $uLName = '';

// Get the current user information
try {
    $stmt = $pdo->prepare("SELECT uFName, uLName, uEmail FROM users WHERE uUserID = :uUserID");
    $stmt->bindParam(':uUserID', $uUserID, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user) {
        $uFName = $user['uFName'];
        $uLName = $user['uLName'];
    } else {
        echo "User not found.";
        exit();
    }
} catch (PDOException $e) {
    echo "Error fetching user details: " . $e->getMessage();
    exit();
}

// Update user information
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uFName = $_POST['uFName'];
    $uLName = $_POST['uLName'];

    try {
        $stmt = $pdo->prepare("UPDATE users SET uFName = :uFName, uLName = :uLName WHERE uUserID = :uUserID");
        $stmt->bindParam(':uFName', $uFName);
        $stmt->bindParam(':uLName', $uLName);
        $stmt->bindParam(':uUserID', $uUserID, PDO::PARAM_INT);
        $stmt->execute();
        header("Location: users_audit.php");
        exit();
    } catch (PDOException $e) {
        echo "Error updating user: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background-color: #2c2c2c;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            color: white;
            width: 400px;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-container .form-group label {
            color: #bbb;
        }
        .form-container .form-control {
            background-color: #444;
            border: 1px solid #555;
            color: white;
        }
        .form-container .form-control:focus {
            background-color: #444;
            border-color: #888;
            box-shadow: none;
        }
        .form-container .btn-primary {
            background-color: #ff5722;
            border-color: #ff5722;
            width: 100%;
        }
        .form-container .btn-primary:hover {
            background-color: #ff3d00;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Edit User</h2>
    <form method="POST" action="edit_user.php?uUserID=<?php echo $uUserID; ?>">
        <div class="form-group">
            <label for="uFName">First Name</label>
            <input type="text" name="uFName" class="form-control" value="<?php echo htmlspecialchars($uFName); ?>" required>
        </div>
        <div class="form-group">
            <label for="uLName">Last Name</label>
            <input type="text" name="uLName" class="form-control" value="<?php echo htmlspecialchars($uLName); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Save Changes</button>
    </form>
</div>

</body>
</html>
