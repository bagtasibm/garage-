<?php
session_start();

// Check if email and OTP session variables are set
if (!isset($_SESSION['email']) || !isset($_SESSION['otp'])) {
    // Redirect to the registration page if no session data is available
    header("Location: page_register.php");
    exit;
}

// Initialize an error message variable
$error_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $enteredOtp = $_POST['otp'];

    // Verify OTP
    if ($enteredOtp == $_SESSION['otp']) {
        // OTP is correct, activate user in the database
        require_once 'connection_cust.php';
        $email = $_SESSION['email'];

        $sql = "UPDATE users SET is_active = 1 WHERE uEmail = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email);

        if ($stmt->execute()) {
            echo '<script>alert("Account activated successfully!"); window.location.href = "page_login.php";</script>';
            exit;
        } else {
            $error_message = "Failed to activate the account. Please try again.";
        }
    } else {
        // OTP is incorrect
        $error_message = "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Verification - Garage Music Studio</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container-fluid {
            height: 100vh;
            display: flex;
        }

        /* Left Section - Form */
        .left-side {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 40px;
            background-color: #fff;
            max-width: 500px; /* Limit the width of the form */
            margin: auto; /* Center the form */
            border-radius: 8px; /* Optional: Add rounded corners */
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); /* Optional: Add a shadow for visual effect */
        }

        /* Right Section - Background Image */
        .right-side {
            background-image: url('img/loginpage.png'); /* Change to your image path */
            background-size: cover;
            background-position: center;
        }

        .form-floating {
            margin-bottom: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .logo {
            display: block;
            margin: 0 auto 1.5rem;
        }

        .alert-danger {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Left Side: OTP Verification Form -->
        <div class="col-md-6 left-side">
            <div class="verification-container w-100 m-auto">
                <center><img class="logo mb-4" src="img/garagelogo.png" alt="Logo" width="150" height="150"></center>
                <h2>OTP Verification</h2>
                <form action="signup_verification.php" method="post">
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($_SESSION['email']); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label for="otp">Enter OTP:</label>
                        <input type="text" class="form-control" id="otp" name="otp" required pattern="^\d{6}$" title="Please enter a 6-digit OTP" placeholder="Enter the OTP" maxlength="6" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                    </div>

                    <!-- Error message below OTP field -->
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary w-100">Verify OTP</button>
                </form>
            </div>
        </div>

        <!-- Right Side: Background Image -->
        <div class="col-md-6 right-side"></div>
    </div>

    <!-- Bootstrap JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
