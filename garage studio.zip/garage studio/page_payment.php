<?php
session_start();
require_once 'connection_cust.php';

if (!isset($_SESSION['reservationID']) || !isset($_SESSION['uUserID'])) {
    // If no reservation ID or user ID, redirect back to reservation page
    header('Location: page_reservation.php');
    exit();
}

$reservationID = $_SESSION['reservationID'];
$userID = $_SESSION['uUserID'];  
$totalCost = $_SESSION['totalCost']; // Get the total cost from the session

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] === UPLOAD_ERR_OK) {
        // Sanitize the uploaded file name
        $uploadDir = 'uploads/';
        $fileName = basename($_FILES['receipt']['name']);
        $safeFileName = preg_replace("/[^a-zA-Z0-9\.\-\_]/", "", $fileName);
        $uploadFile = $uploadDir . $safeFileName;

        // Validate file type
        $fileType = strtolower(pathinfo($uploadFile, PATHINFO_EXTENSION));
        $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($fileType, $allowedTypes)) {
            // Check file size (optional, set a limit if needed, e.g., 5MB)
            if ($_FILES['receipt']['size'] <= 5000000) { // 5MB limit
                // Move the uploaded file to the uploads directory
                if (move_uploaded_file($_FILES['receipt']['tmp_name'], $uploadFile)) {
                    // Update reservation with payment status and receipt path
                    $sql = "UPDATE reservations SET paymentStatus = 'completed', receiptPath = :receiptPath WHERE reservationID = :reservationID";
                    $stmt = $pdo->prepare($sql);
                    $stmt->bindParam(':receiptPath', $uploadFile);
                    $stmt->bindParam(':reservationID', $reservationID);

                    if ($stmt->execute()) {
                        // Insert payment record into the payments table
                        $sqlPayment = "INSERT INTO payments (reservationID, userID, totalCost, paymentStatus, receiptPath) 
                                       VALUES (:reservationID, :userID, :totalCost, 'completed', :receiptPath)";
                        $stmtPayment = $pdo->prepare($sqlPayment);
                        $stmtPayment->bindParam(':reservationID', $reservationID);
                        $stmtPayment->bindParam(':userID', $userID);
                        $stmtPayment->bindParam(':totalCost', $totalCost);  // Total cost including instrument rental
                        $stmtPayment->bindParam(':receiptPath', $uploadFile);

                        if ($stmtPayment->execute()) {
                            // Clear session reservation ID and redirect to success page
                            unset($_SESSION['reservationID']);
                            unset($_SESSION['totalCost']);
                            echo '<script>alert("Payment successful!"); window.location.href = "customer_page.php";</script>';
                        } else {
                            echo '<div class="alert alert-danger">Failed to record payment. Please try again.</div>';
                        }
                    } else {
                        echo '<div class="alert alert-danger">Failed to update reservation. Please try again.</div>';
                    }
                } else {
                    echo '<div class="alert alert-danger">Failed to upload the file. Please try again.</div>';
                }
            } else {
                echo '<div class="alert alert-danger">File size exceeds the limit of 5MB. Please upload a smaller file.</div>';
            }
        } else {
            echo '<div class="alert alert-danger">Invalid file type. Only JPG, JPEG, PNG, and GIF files are allowed.</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Please upload a valid receipt.</div>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: black; /* Black background */
            color: white; /* White text */
        }
        .container-payment {
            background-color: #444; /* Dark gray background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            margin-top: 50px;
        }
        .file-upload-container {
            display: flex;
            justify-content: center; /* Center horizontally */
            margin-top: 10px; /* Add some space above */
        }
        .file-upload {
            width: 50%; /* Adjust the width of the file input */
            max-width: 250px; /* Set a max width */
        }
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
    </style>
</head>
<body>
    <div class="container text-center">
        <div class="container-payment">
            <h2 class="mt-2">Payment</h2>
            <p>Reservation cost: ₱<?php echo number_format($totalCost, 2); // Display the total cost ?></p>

            <!-- Fake QR Code -->
            <div class="text-center mb-4">
                <img src="qrcode.png" alt="Fake QR Code" style="width: 200px; height: 200px;">
                <p>Pay at Garage Music Studio</p>
            </div>

            <form action="page_payment.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="receipt">Upload Receipt:</label>
                    <div class="file-upload-container">
                        <input type="file" class="form-control-file file-upload" id="receipt" name="receipt" accept=".jpg,.jpeg,.png,.gif" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-success mt-4">Complete Payment</button>
            </form>
        </div>
    </div>
</body>
</html>
