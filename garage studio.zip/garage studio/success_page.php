<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #000000;
            font-family: Arial, sans-serif;
            color: #ffffff;
        }
        .container {
            margin-top: 100px;
            text-align: center;
        }
        .message-success {
            background-color: #28a745;
            color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            display: inline-block;
        }
        .btn-primary {
            margin-top: 20px;
            background-color: #ff4500;
            border-color: #ff4500;
        }
        .btn-primary:hover {
            background-color: #ff6347;
            border-color: #ff6347;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="message-success">
            <h2>Your instrument request has been successfully submitted!</h2>
        </div>
        <a href="customer_page.php" class="btn btn-primary">Return to Dashboard</a>
    </div>
</body>
</html>