<?php
session_start();
require_once 'connection_cust.php'; // Include your database connection

// Check if the user is logged in
if (!isset($_SESSION['uUserID'])) {
    header('Location: page_login.php');
    exit();
}

// Get user ID from session
$userID = $_SESSION['uUserID'];

// Initialize variables
$uFName = '';
$uLName = '';
$message = '';

// Fetch user details from the database
try {
    $sql = "SELECT uFName, uLName, uPhoneNumber, uEmail FROM users WHERE uUserID = :userID";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $uFName = $user['uFName'];
        $uLName = $user['uLName'];
    } else {
        $message = "User not found.";
    }
} catch (PDOException $e) {
    $message = "Error fetching user details: " . $e->getMessage();
}

// Handle form submission for updating name
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uFName = $_POST['uFName'];
    $uLName = $_POST['uLName'];

    try {
        $sql = "UPDATE users SET uFName = :uFName, uLName = :uLName WHERE uUserID = :userID";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':uFName', $uFName, PDO::PARAM_STR);
        $stmt->bindParam(':uLName', $uLName, PDO::PARAM_STR);
        $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
        if ($stmt->execute()) {
            $message = "Profile updated successfully!";
        } else {
            $message = "Error updating profile.";
        }
    } catch (PDOException $e) {
        $message = "Database Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 400px;
            margin: 100px auto;
            background-color: #333; /* Dark background */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            color: white;
        }
        .container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #f0f0f0;
        }
        .form-control {
            background-color: #555; /* Darker input background */
            border: none;
            color: white;
            padding: 10px;
            border-radius: 5px;
        }
        .form-control[disabled] {
            background-color: #555 !important; /* Same background for disabled inputs */
            color: #bdbdbd !important; /* Light gray color for text in disabled inputs */
        }
        .btn-primary {
            background-color: #ff5722; /* Orange button */
            border: none;
            padding: 10px 20px;
            width: 100%;
        }
        .btn-primary:hover {
            background-color: #e64a19;
        }
        .btn-back {
            background-color: #777;
            border: none;
            color: white;
            padding: 10px 20px;
            width: 100%;
        }
        .btn-back:hover {
            background-color: #666;
        }
        .message {
            margin-top: 20px;
            text-align: center;
            color: #ff5722;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Profile</h2>
    <?php if ($message): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($message); ?></div>
    <?php endif; ?>

    <form method="POST" action="page_profile.php">
        <div class="form-group">
            <label for="uFName">First Name</label>
            <input type="text" class="form-control" id="uFName" name="uFName" value="<?php echo htmlspecialchars($uFName); ?>" required>
        </div>
        <div class="form-group">
            <label for="uLName">Last Name</label>
            <input type="text" class="form-control" id="uLName" name="uLName" value="<?php echo htmlspecialchars($uLName); ?>" required>
        </div>
        <div class="form-group">
            <label for="uPhoneNumber">Phone Number</label>
            <input type="text" class="form-control" id="uPhoneNumber" value="<?php echo htmlspecialchars($user['uPhoneNumber']); ?>" disabled>
        </div>
        <div class="form-group">
            <label for="uEmail">Email</label>
            <input type="email" class="form-control" id="uEmail" value="<?php echo htmlspecialchars($user['uEmail']); ?>" disabled>
        </div>
        <button type="submit" class="btn btn-primary mt-4">Save Changes</button>
        <a href="customer_page.php" class="btn btn-back mt-3">Back to Dashboard</a>
    </form>
</div>

</body>
</html>
