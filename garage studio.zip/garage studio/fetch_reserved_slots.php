<?php
require_once 'connection_cust.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reservationDate'])) {
    $reservationDate = $_POST['reservationDate'];

    // Fetch reserved time slots for the selected date
    $sql = "SELECT reservationTime, paymentStatus FROM reservations WHERE reservationDate = :reservationDate AND (paymentStatus = 'pending' OR paymentStatus = 'completed')";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':reservationDate', $reservationDate);
    $stmt->execute();
    $reservedSlots = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($reservedSlots)) {
        echo '<table class="table table-bordered">';
        echo '<thead><tr><th>Time</th><th>Status</th></tr></thead><tbody>';
        foreach ($reservedSlots as $slot) {
            // Convert reservationTime to 12-hour format with AM/PM
            $timeFormatted = date("h:i A", strtotime($slot['reservationTime']));
            echo '<tr><td>' . htmlspecialchars($timeFormatted) . '</td><td>' . htmlspecialchars($slot['paymentStatus']) . '</td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p>No reservations for the selected date.</p>';
    }
}
?>
