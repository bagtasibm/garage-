<!-- sidebar.php -->
<div class="sidebar" style="background-color: #CCCCCC; height: 100vh; width: 250px; position: fixed; top: 0; left: 0;">
    <div class="logo text-center py-3">
        <img src="img/garagelogo.png" alt="Garage Music Studio" style="width: 200px;">
    </div>
    <ul class="list-unstyled px-3">
        <li class="py-3">
            <a href="page_admin.php" class="text-dark" style="text-decoration: none; font-size: 18px;">Dashboard</a>
        </li>
        <li class="py-3">
            <a href="users_audit.php" class="text-dark" style="text-decoration: none; font-size: 18px;">Users</a>
        </li>
        <li class="py-3">
            <a href="auditlog.php" class="text-dark" style="text-decoration: none; font-size: 18px;">Audit Log</a>
        </li>
        <li class="py-3">
            <a href="logout.php" class="text-dark" style="text-decoration: none; font-size: 18px;">Logout</a>
        </li>
    </ul>
</div>
