<?php
session_start();
require_once 'connection_cust.php'; // Include your database connection
require_once('tcpdf/tcpdf.php'); // Include TCPDF library

// Check if the user is logged in and has appropriate access level
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 1) {
    header('Location: page_login.php');
    exit();
}

// Initialize variables for search and filter
$searchQuery = '';
$statusFilter = 'all';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['search'])) {
        $searchQuery = $_POST['search'];
    }
    if (!empty($_POST['statusFilter'])) {
        $statusFilter = $_POST['statusFilter'];
    }
}

// Build the SQL query based on the search and status filter
$sql = "SELECT uUserID, uEmail, uLevel, is_active FROM users WHERE 1=1";

// Add the search filter
if ($searchQuery) {
    $sql .= " AND (uUserID LIKE :searchQuery OR uEmail LIKE :searchQuery OR uLevel LIKE :searchQuery)";
}

// Add the status filter
if ($statusFilter != 'all') {
    $isActive = ($statusFilter == 'active') ? 1 : 0;
    $sql .= " AND is_active = :statusFilter";
}

try {
    $stmt = $pdo->prepare($sql);

    // Bind parameters for search query and status filter
    if ($searchQuery) {
        $searchTerm = "%" . $searchQuery . "%";
        $stmt->bindParam(':searchQuery', $searchTerm);
    }
    if ($statusFilter != 'all') {
        $stmt->bindParam(':statusFilter', $isActive, PDO::PARAM_INT);
    }

    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage();
    exit();
}

// Check if the PDF generation is requested
if (isset($_GET['generate_pdf']) && $_GET['generate_pdf'] == 'true') {
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Your Name');
    $pdf->SetTitle('User Audit Report');
    $pdf->SetSubject('User Audit');

    // Disable header and footer to avoid issues
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // Add a page
    $pdf->AddPage();

    // Set font
    $pdf->SetFont('helvetica', '', 12);

    // Create HTML content for the PDF
    $html = '<h2>User Audit Report</h2>';
    $html .= '<table border="1" cellpadding="5">';
    $html .= '<thead>
                <tr>
                    <th>User ID</th>
                    <th>Email</th>
                    <th>Level</th>
                    <th>Status</th>
                </tr>
              </thead>';
    $html .= '<tbody>';
    foreach ($users as $user) {
        $html .= '<tr>';
        $html .= '<td>' . htmlspecialchars($user['uUserID']) . '</td>';
        $html .= '<td>' . htmlspecialchars($user['uEmail']) . '</td>';
        $html .= '<td>';
        switch($user['uLevel']) {
            case 1: $html .= 'Admin'; break;
            case 2: $html .= 'Customer'; break;
            case 3: $html .= 'Staff'; break;
            default: $html .= 'Unknown'; break;
        }
        $html .= '</td>';
        $html .= '<td>' . ($user['is_active'] ? 'Active' : 'Inactive') . '</td>';
        $html .= '</tr>';
    }
    $html .= '</tbody></table>';

    // Output the HTML content to the PDF
    $pdf->writeHTML($html, true, false, true, false, '');

    // Close and output PDF document
    $pdf->Output('user_audit_report.pdf', 'D'); // 'D' for download, 'I' for inline view

    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto; /* Center the content */
        }
        #searchInput, #statusFilter {
            max-width: 300px; /* Shorten the search and filter inputs */
            display: inline-block;
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="container">
            <h2 class="text-center">Users Management</h2>

            <!-- Search and Filter Form -->
            <form method="POST" action="users_audit.php">
                <input type="text" name="search" class="form-control mb-2" placeholder="Search for user ID, email, or level" value="<?php echo htmlspecialchars($searchQuery); ?>">
                <!-- Dropdown to filter by status -->
                <select name="statusFilter" class="form-control mb-4">
                    <option value="all" <?php if ($statusFilter == 'all') echo 'selected'; ?>>All Status</option>
                    <option value="active" <?php if ($statusFilter == 'active') echo 'selected'; ?>>Active</option>
                    <option value="inactive" <?php if ($statusFilter == 'inactive') echo 'selected'; ?>>Inactive</option>
                </select>
                <button type="submit" class="btn btn-primary mb-4">Search & Filter</button>
                <!-- Add Generate PDF button -->
                <a href="users_audit.php?generate_pdf=true" class="btn btn-secondary mb-4">Generate PDF</a>
            </form>

            <?php if (count($users) > 0): ?>
                <table class="table table-bordered" id="usersTable">
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Email</th>
                            <th>Level</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['uUserID']); ?></td>
                                <td><?php echo htmlspecialchars($user['uEmail']); ?></td>
                                <td>
                                    <?php 
                                        switch($user['uLevel']) {
                                            case 1: echo 'Admin'; break;
                                            case 2: echo 'Customer'; break;
                                            case 3: echo 'Staff'; break;
                                            default: echo 'Unknown'; break;
                                        }
                                    ?>
                                </td>
                                <td><?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?></td>
                                <td>
                                    <a href="edit_user.php?uUserID=<?php echo $user['uUserID']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="delete_user.php?uUserID=<?php echo $user['uUserID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info">No users found.</div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
