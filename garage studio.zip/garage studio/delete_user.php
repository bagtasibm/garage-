<?php
session_start();
require_once 'connection_cust.php'; // Include your database connection

// Check if the user is logged in and has appropriate access level
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 1) {
    header('Location: page_login.php');
    exit();
}

// Check if user ID is set in the URL
if (!isset($_GET['uUserID'])) {
    header('Location: users_audit.php');
    exit();
}

$uUserID = $_GET['uUserID'];

try {
    // Begin transaction to ensure data integrity
    $pdo->beginTransaction();

    // Delete related records from the audituser table first
    $stmt = $pdo->prepare("DELETE FROM audituser WHERE uUserID = :uUserID");
    $stmt->bindParam(':uUserID', $uUserID, PDO::PARAM_INT);
    $stmt->execute();

    // Now, delete the user from the users table
    $stmt = $pdo->prepare("DELETE FROM users WHERE uUserID = :uUserID");
    $stmt->bindParam(':uUserID', $uUserID, PDO::PARAM_INT);
    $stmt->execute();

    // Commit transaction
    $pdo->commit();

    // Redirect back to the users audit page
    header('Location: users_audit.php');
    exit();
} catch (PDOException $e) {
    // Rollback transaction if something goes wrong
    $pdo->rollBack();
    echo "Error deleting user: " . $e->getMessage();
}
