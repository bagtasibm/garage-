<?php
session_start();
require_once 'connection_cust.php';

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/PHPMailer/vendor/autoload.php'; // Ensure PHPMailer is installed correctly

// Initialize an error message variable
$error_message = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the email from the form
    $email = $_POST['email'];

    try {
        // Check if the email exists in the database
        $sql = "SELECT * FROM users WHERE uEmail = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            // Generate a 6-digit OTP code for password reset
            $resetOtpCode = rand(100000, 999999);

            // Store the OTP and email in session
            $_SESSION['resetEmail'] = $email;
            $_SESSION['resetOtp'] = $resetOtpCode;

            // Send OTP Email using PHPMailer
            $mail = new PHPMailer(true);

            try {
                // Server settings
                $mail->isSMTP();                                             // Send using SMTP
                $mail->Host       = 'smtp.gmail.com';                        // Set the SMTP server to send through
                $mail->SMTPAuth   = true;                                    // Enable SMTP authentication
                $mail->Username   = 'zerovstore@gmail.com';                  // SMTP username (your Gmail address)
                $mail->Password   = 'fxqe wqwy silt ysln';                   // SMTP password (Gmail password or App password)
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;          // Enable TLS encryption
                $mail->Port       = 587;                                     // TCP port to connect to

                // Recipients
                $mail->setFrom('zerovstore@gmail.com', 'Password Reset');    // Sender email
                $mail->addAddress($email);                                   // Add recipient email

                // Content
                $mail->isHTML(true);                                         // Set email format to HTML
                $mail->Subject = 'Password Reset Request';
                $mail->Body    = "Hello,<br><br>Your password reset code is: <b>$resetOtpCode</b><br><br>Please use this code to reset your password.";
                $mail->AltBody = "Hello, Your password reset code is: $resetOtpCode. Please use this code to reset your password.";

                // Send the email
                $mail->send();

                // Redirect to OTP verification page for password reset
                echo '<script>alert("A password reset code has been sent to your email. Please check your inbox."); window.location.href = "verify_otp.php";</script>';

            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            $error_message = "Email address not found!";
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Garage Music Studio</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container-fluid {
            height: 100vh;
            display: flex;
        }

        /* Left Section - Form */
        .left-side {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 40px;
            background-color: #fff;
            max-width: 500px; /* Limit the width of the form */
            margin: auto; /* Center the form */
            border-radius: 8px; /* Optional: Add rounded corners */
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); /* Optional: Add a shadow for visual effect */
        }

        /* Right Section - Background Image */
        .right-side {
            background-image: url('img/loginpage.png'); /* Change to your image path */
            background-size: cover;
            background-position: center;
        }

        .form-floating {
            margin-bottom: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo {
            display: block;
            margin: 0 auto 1.5rem;
        }

        .alert-danger {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Left Side: Forgot Password Form -->
        <div class="col-md-6 left-side">
            <div class="forgot-password-container w-100 m-auto">
                <center><img class="logo mb-4" src="img/garagelogo.png" alt="Logo" width="150" height="150"></center>
                <h2>Forgot Password</h2>
                <form action="process_forgotpass.php" method="POST">
                    <div class="form-group">
                        <label for="email">Enter Your Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                        <!-- Display the error message below email input if it exists -->
                        <?php if (!empty($error_message)): ?>
                            <div class="alert alert-danger mt-2"><?php echo htmlspecialchars($error_message); ?></div>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Send Reset Code</button>
                </form>
            </div>
        </div>

        <!-- Right Side: Background Image -->
        <div class="col-md-6 right-side"></div>
    </div>

    <!-- Bootstrap JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>