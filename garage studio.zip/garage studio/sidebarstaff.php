<div class="sidebar">
    <div class="sidebar-heading">
        <img src="src/garagelogo.png" alt="Logo" class="sidebar-logo"> <!-- Add your logo here -->
        Staff Dashboard
    </div>
    <ul>
        <li><a href="page_staff.php"><i class="fas fa-home"></i> Dashboard</a></li>
        <li><a href="pending_request.php"><i class="fas fa-clock"></i> Pending Requests</a></li>
        <li><a href="accepted_request.php"><i class="fas fa-check-circle"></i> Accepted Requests</a></li>
        <li><a href="view_users.php"><i class="fas fa-users"></i> Users</a></li>
        <li><a href="auditlog.php"><i class="fas fa-clipboard-list"></i> Audit Log</a></li>
    </ul>
    <form action="logout.php" method="POST" class="logout-btn">
        <button type="submit" name="logout" class="btn btn-danger btn-block"><i class="fas fa-sign-out-alt"></i> Logout</button>
    </form>
</div>
