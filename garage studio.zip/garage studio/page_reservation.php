<?php
session_start();
require_once 'connection_cust.php';

// Check if the user is logged in
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 2) {
    echo '<script>alert("You must be logged in to make a reservation."); window.location.href = "page_login.php";</script>';
    exit();
}

// Get user ID from session
$userID = $_SESSION['uUserID'];

// Fetch available instruments
$sqlInstruments = "SELECT instrument_id, instrument_name, brand, rental_price FROM instruments WHERE availability_status = 'available'";
$stmtInstruments = $pdo->prepare($sqlInstruments);
$stmtInstruments->execute();
$instruments = $stmtInstruments->fetchAll(PDO::FETCH_ASSOC);

// Fetch available pedals
$sqlPedals = "SELECT pedal_id, pedal_name, brand, rental_price FROM pedals WHERE availability_status = 'available'";
$stmtPedals = $pdo->prepare($sqlPedals);
$stmtPedals->execute();
$pedals = $stmtPedals->fetchAll(PDO::FETCH_ASSOC);

// Base reservation cost
$baseCost = 150.00;

// Fetch reserved slots if date is set
$reservedSlots = [];
if (isset($_POST['reservationDate'])) {
    $reservationDate = $_POST['reservationDate'];

    // Fetch reserved time slots for the selected date
    $sqlReserved = "SELECT reservationTime, paymentStatus FROM reservations WHERE reservationDate = :reservationDate AND (paymentStatus = 'pending' OR paymentStatus = 'completed')";
    $stmtReserved = $pdo->prepare($sqlReserved);
    $stmtReserved->bindParam(':reservationDate', $reservationDate);
    $stmtReserved->execute();
    $reservedSlots = $stmtReserved->fetchAll(PDO::FETCH_ASSOC);
} else {
    $reservationDate = null;
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submitReservation'])) {
    $reservationDate = $_POST['reservationDate'];
    $reservationTime = $_POST['reservationTime'];
    $instrumentIDs = $_POST['instrumentID'] ?? []; // Get the array of selected instrument IDs, default to empty array if not set
    $pedalIDs = $_POST['pedalID'] ?? []; // Get the array of selected pedal IDs, default to empty array if not set

    // Set initial total cost to base reservation cost
    $totalCost = $baseCost;

    if (!empty($instrumentIDs)) {
        // Loop through each selected instrument and add its rental price to the total cost
        foreach ($instrumentIDs as $instrumentID) {
            $sqlInstrumentPrice = "SELECT rental_price FROM instruments WHERE instrument_id = :instrumentID";
            $stmtInstrumentPrice = $pdo->prepare($sqlInstrumentPrice);
            $stmtInstrumentPrice->bindParam(':instrumentID', $instrumentID, PDO::PARAM_INT);
            $stmtInstrumentPrice->execute();
            $instrumentPrice = $stmtInstrumentPrice->fetchColumn();

            if ($instrumentPrice) {
                $totalCost += $instrumentPrice; // Add instrument price to the total cost
            }
        }
    }

    if (!empty($pedalIDs)) {
        // Loop through each selected pedal and add its rental price to the total cost
        foreach ($pedalIDs as $pedalID) {
            $sqlPedalPrice = "SELECT rental_price FROM pedals WHERE pedal_id = :pedalID";
            $stmtPedalPrice = $pdo->prepare($sqlPedalPrice);
            $stmtPedalPrice->bindParam(':pedalID', $pedalID, PDO::PARAM_INT);
            $stmtPedalPrice->execute();
            $pedalPrice = $stmtPedalPrice->fetchColumn();

            if ($pedalPrice) {
                $totalCost += $pedalPrice; // Add pedal price to the total cost
            }
        }
    }

    // Check if the reservation date is today, tomorrow, or yesterday
    if (strtotime($reservationDate) <= strtotime('tomorrow')) {
        echo '<div class="alert alert-danger">Reservations cannot be made for today, tomorrow, or any past date. Please select a date after tomorrow.</div>';
    } else {
        // Check if the date and time are already reserved with a pending or completed status
        $sqlCheckPending = "SELECT COUNT(*) FROM reservations 
                            WHERE reservationDate = :reservationDate 
                            AND reservationTime = :reservationTime 
                            AND (paymentStatus = 'pending' OR paymentStatus = 'completed')";
        $stmtCheckPending = $pdo->prepare($sqlCheckPending);
        $stmtCheckPending->bindParam(':reservationDate', $reservationDate);
        $stmtCheckPending->bindParam(':reservationTime', $reservationTime);
        $stmtCheckPending->execute();
        $pendingCount = $stmtCheckPending->fetchColumn();

        if ($pendingCount > 0) {
            // If there's already a pending or completed reservation for this date and time
            echo '<div class="alert alert-danger">This date and time are already reserved. Please choose another time.</div>';
        } else {
            // Insert reservation details into the database
            try {
                $selectedInstruments = implode(",", $instrumentIDs); // Convert instrument array to comma-separated string
                $selectedPedals = implode(",", $pedalIDs); // Convert pedal array to comma-separated string

                $sql = "INSERT INTO reservations (uUserID, instrumentID, pedalIDs, reservationDate, reservationTime, totalCost, paymentStatus) 
                VALUES (:userID, :selectedInstruments, :selectedPedals, :reservationDate, :reservationTime, :totalCost, 'pending')";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':userID', $userID, PDO::PARAM_INT);
                $stmt->bindParam(':selectedInstruments', $selectedInstruments);
                $stmt->bindParam(':selectedPedals', $selectedPedals);
                $stmt->bindParam(':reservationDate', $reservationDate);
                $stmt->bindParam(':reservationTime', $reservationTime);
                $stmt->bindParam(':totalCost', $totalCost);
                // Execute the statement
                if ($stmt->execute()) {
                    // Get the last inserted reservation ID for payment processing
                    $reservationID = $pdo->lastInsertId();

                    // Redirect to payment page
                    $_SESSION['reservationID'] = $reservationID;
                    $_SESSION['totalCost'] = $totalCost; // Store total cost in session for payment processing
                    echo '<script>alert("Reservation successful! Proceed to payment."); window.location.href = "page_payment2.php";</script>';
                } else {
                    echo '<div class="alert alert-danger">Failed to create reservation. Please try again.</div>';
                }
            } catch (Exception $e) {
                echo "Error: " . $e->getMessage(); // Log SQL error for debugging
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make a Reservation</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #000000; /* Set background color to black */
            font-family: Arial, sans-serif;
            color: #ffffff; /* White text for better contrast */
        }
        .container {
            margin-top: 50px;
        }
        .note-container, .reserved-container {
            background-color: #333333; /* Match color to the reservation box */
            color: #f0f0f0; /* Set the text color to the same as 'Reserve a Slot' */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        .reservation-container {
            background-color: #333333; /* Dark background */
            color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }
        .reservation-container h2 {
            color: #f0f0f0; /* Slightly lighter color for the heading */
            text-align: center;
            margin-bottom: 30px;
        }
        .form-control.custom-input {
            background-color: #444444; /* Darker input field */
            color: #ffffff;
            border: 1px solid #555555;
        }
        .form-control.custom-input:focus {
            border-color: #777777;
            background-color: #555555;
        }
        .btn-primary, .back-button {
            background-color: #ff4500; /* Set both buttons to the same orange color */
            border-color: #ff4500;
        }
        .btn-primary:hover, .back-button:hover {
            background-color: #ff6347; /* Lighter orange on hover for both buttons */
            border-color: #ff6347;
        }
        .back-button {
            color: #ffffff; /* White arrow for better visibility */
            border: none;
           
            /* Keep background transparent for icon */
            font-size: 24px;
            background-color: transparent; 
        }
        .reserved-table {
            color: #f0f0f0; /* Match text color to other sections */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <!-- Note Section -->
            <div class="col-md-3">
                <div class="note-container">
                    <h4>Note:</h4>
                    <p><strong>Instrument:</strong> ₱100</p>
                    <p><strong>Pedal:</strong> ₱100</p>
                    <p><strong>Reservation:</strong> ₱150</p>
                </div>
            </div>
            
            <!-- Reservation Form Section -->
            <div class="col-md-6">
                <div class="reservation-container">
                    <!-- Back arrow icon button -->
                    <button class="back-button" onclick="window.location.href='customer_page.php';">
                        &#x2190; <!-- Left arrow icon -->
                    </button>
                    <h2>Reserve a Slot</h2>
                    <form action="page_reservation.php" method="POST">
                        <!-- Instrument Selection -->
                        <div class="form-group">
                            <h4><label for="instrumentID">Select Instruments</label></h4>
                            <div class="custom-input" id="instrumentID">
                                <?php foreach ($instruments as $instrument): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="instrumentID[]" value="<?php echo $instrument['instrument_id']; ?>" id="instrument<?php echo $instrument['instrument_id']; ?>">
                                        <label class="form-check-label" for="instrument<?php echo $instrument['instrument_id']; ?>">
                                            <?php echo $instrument['instrument_name'] . ' (' . $instrument['brand'] . ') - ₱' . $instrument['rental_price']; ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <!-- Pedal Selection -->
                        <div class="form-group">
                            <h4><label for="pedalID">Select Pedals</label></h4>
                            <div class="custom-input" id="pedalID">
                                <?php foreach ($pedals as $pedal): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="pedalID[]" value="<?php echo $pedal['pedal_id']; ?>" id="pedal<?php echo $pedal['pedal_id']; ?>">
                                        <label class="form-check-label" for="pedal<?php echo $pedal['pedal_id']; ?>">
                                            <?php echo $pedal['pedal_name'] . ' (' . $pedal['brand'] . ') - ₱' . $pedal['rental_price']; ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <!-- Reservation Date -->
                        <div class="form-group">
                            <label for="reservationDate">Select Date</label>
                            <input type="date" class="form-control custom-input" id="reservationDate" name="reservationDate" required>
                        </div>

                        <!-- Reservation Time -->
                        <div class="form-group">
                            <label for="reservationTime">Select Time (8:00 AM to 10:00 PM)</label>
                            <select class="form-control custom-input" id="reservationTime" name="reservationTime" required>
                                <option value="08:00">08:00 AM</option>
                                <option value="09:00">09:00 AM</option>
                                <option value="10:00">10:00 AM</option>
                                <option value="11:00">11:00 AM</option>
                                <option value="12:00">12:00 PM</option>
                                <option value="13:00">01:00 PM</option>
                                <option value="14:00">02:00 PM</option>
                                <option value="15:00">03:00 PM</option>
                                <option value="16:00">04:00 PM</option>
                                <option value="17:00">05:00 PM</option>
                                <option value="18:00">06:00 PM</option>
                                <option value="19:00">07:00 PM</option>
                                <option value="20:00">08:00 PM</option>
                                <option value="21:00">09:00 PM</option>
                                <option value="22:00">10:00 PM</option>
                            </select>
                        </div>

                        <button type="submit" name="submitReservation" class="btn btn-primary">Proceed to Payment</button>
                    </form>
                </div>
            </div>

            <!-- Reserved Date and Time Section -->
            <div class="col-md-3">
                <div class="reserved-container">
                    <h4>Reserved Date & Time</h4>
                    <div class="reserved-table" id="reservedSlots">
                        <p>Please select a date to view reserved time slots.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Set the minimum selectable date to the day after tomorrow
            let dayAfterTomorrow = new Date();
            dayAfterTomorrow.setDate(dayAfterTomorrow.getDate() + 2);
            let dayAfterTomorrowString = dayAfterTomorrow.toISOString().split('T')[0];
            document.getElementById("reservationDate").setAttribute("min", dayAfterTomorrowString);

            // Fetch reserved time slots when a date is selected
            document.getElementById("reservationDate").addEventListener("change", function () {
                let selectedDate = this.value;
                if (selectedDate) {
                    fetchReservedSlots(selectedDate);
                }
            });

            function fetchReservedSlots(date) {
                // Make AJAX request to fetch reserved slots for the selected date
                let xhr = new XMLHttpRequest();
                xhr.open("POST", "fetch_reserved_slots.php", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        document.getElementById("reservedSlots").innerHTML = xhr.responseText;
                    }
                };
                xhr.send("reservationDate=" + date);
            }
        });
    </script>
</body>
</html>
