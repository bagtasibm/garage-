
<?php
// Start the session
session_start();

// Include your database connection file
include 'connection_cust.php';

// Check if the user is logged in by checking the session variable
if (!isset($_SESSION['uUserID'])) {
    die('You need to login first to make a request.');
}

// Get the logged-in user's first name and user ID from the session
$uUserID = $_SESSION['uUserID'];       // Using uUserID (matching the users table)
$user_fname = $_SESSION['user_fname']; // Using user_fname

// Fixed price for the pedal
$price = 100;  // Fixed price of 50 for the pedal

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Get form data (using PDO's prepared statements for security)
    $pedal_name = $_POST['pedal_name'];
    $model = $_POST['model'];
    $description = $_POST['description'];

    // Create a directory for the user if it doesn't exist
    $user_dir = "pedals/" . $user_fname . "/";
    if (!is_dir($user_dir)) {
        mkdir($user_dir, 0777, true);
    }

    // Handle multiple images
    $image_count = count($_FILES['images']['name']);
    $uploaded_images = [];

    for ($i = 0; $i < $image_count; $i++) {
        $image_name = basename($_FILES['images']['name'][$i]);
        $target_file = $user_dir . $image_name;
        
        // Move uploaded file to the user's directory
        if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $target_file)) {
            $uploaded_images[] = $image_name;
        }
    }

    // Convert the array of uploaded images to a comma-separated string
    $images = implode(",", $uploaded_images);

    // Insert the pedal data into the database using PDO
    $sql = "INSERT INTO user_pedals (pedal_name, model, description, images, price, uUserID)
            VALUES (:pedal_name, :model, :description, :images, :price, :uUserID)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':pedal_name', $pedal_name);
    $stmt->bindParam(':model', $model);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':images', $images);
    $stmt->bindParam(':price', $price);  // Binding the fixed price
    $stmt->bindParam(':uUserID', $uUserID);

    if ($stmt->execute()) {
        // Set a success message in session
        $_SESSION['success_message'] = "Your pedal request has been submitted!";
        // Redirect to the same page to show the message
        header("Location: rent_pedals.php");
        exit(); // Always call exit after a header redirection
    } else {
        echo "Error: Could not submit your request.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent Your Pedal</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        
        body {
            background-color: #000000; /* Black background for the entire page */
            font-family: Arial, sans-serif;
            color: #ffffff; /* White text for better contrast */
        }
        .container {
            margin-top: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .rent-container {
            background-color: #333333; /* Dark grey background */
            color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.5);
            width: 400px;
            text-align: center;
        }
        h2 {
            color: #f0f0f0; /* Slightly lighter color for the heading */
            text-align: center;
            margin-bottom: 20px;
        }
        .message-success {
            background-color: #28a745; /* Green background for success message */
            color: #ffffff;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        label {
            color: #ffffff; /* White label text */
        }
        .form-control {
            background-color: #444444; /* Darker input field */
            color: #ffffff;
            border: none;
            padding: 10px;
        }
        .form-control:focus {
            background-color: #555555; /* Lighter dark on focus */
            color: #ffffff;
        }
        .btn-primary {
            background-color: #ff4500; /* Orange button */
            border-color: #ff4500;
            padding: 10px 20px;
            font-size: 16px;
            width: 100%;
            margin-top: 20px;
            color: #ffffff; /* White text color */
        }

        .btn-primary:hover {
            background-color: #ff6347; /* Lighter orange on hover */
            border-color: #ff6347;
            color: #ffffff; /* Keep white text on hover */
        }

        .btn-back {
            background-color: #ff4500; /* Same color as Submit button */
            border-color: #ff4500;
            padding: 10px 20px;
            font-size: 16px;
            width: 100%;
            margin-top: 10px; /* Some margin to separate from the Submit button */
            color: #ffffff; /* White text color */
        }

        .btn-back:hover {
            background-color: #ff6347; /* Lighter orange on hover */
            border-color: #ff6347;
            color: #ffffff; /* Keep white text on hover */
        }
    </style>
    
</head>
<body>
    <div class="container">
        <div class="rent-container">
            <!-- Check for success message in session and display it -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="message-success">
                    <?php echo $_SESSION['success_message']; ?>
                    <?php unset($_SESSION['success_message']); // Clear the message ?>
                </div>
            <?php endif; ?>
            
            <h2>Rent Your Pedal</h2>
            <form action="rent_pedals.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="pedal_name">Pedal Name:</label>
                    <input type="text" class="form-control" id="pedal_name" name="pedal_name" required>
                </div>
                <div class="form-group">
                    <label for="model">Model:</label>
                    <input type="text" class="form-control" id="model" name="model" required>
                </div>
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="images">Upload Images of Your Pedal:</label>
                    <input type="file" class="form-control" id="images" name="images[]" accept="image/*" multiple required>
                </div>
                <input type="submit" class="btn btn-primary" name="submit" value="Submit">
            </form>
            
            <!-- Back Button -->
            <button class="btn btn-back" onclick="window.location.href='customer_page.php';">Back to Customer Page</button>
        </div>
    </div>
</body>
</html>
