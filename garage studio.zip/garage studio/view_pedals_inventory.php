<?php
session_start();
require_once 'connection_cust.php'; // Include your database connection

// Check if the user is logged in and has appropriate access level (assuming uLevel 3 is staff)
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 3) { 
    header('Location: page_login.php');
    exit();
}

// Update pedal details if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_pedal'])) {
        $pedalID = $_POST['pedal_id'];
        $pedalName = $_POST['pedal_name'];
        $availabilityStatus = $_POST['availability_status']; // Add this field to the form
        $rentalPrice = $_POST['rental_price']; // Add this field to the form

        try {
            // Update the pedal in the database
            $sql = "UPDATE pedals SET pedal_name = :pedal_name, availability_status = :availability_status, rental_price = :rental_price WHERE pedal_id = :pedal_id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':pedal_name', $pedalName);
            $stmt->bindParam(':availability_status', $availabilityStatus);
            $stmt->bindParam(':rental_price', $rentalPrice);
            $stmt->bindParam(':pedal_id', $pedalID);
            $stmt->execute();
            echo '<script>alert("Pedal updated successfully!");</script>';
        } catch (PDOException $e) {
            echo "Database Error: " . $e->getMessage();
            exit();
        }
    }

    // Handle pedal deletion
    if (isset($_POST['delete_pedal'])) {
        $pedalID = $_POST['pedal_id'];

        try {
            // Delete the pedal from the database
            $sql = "DELETE FROM pedals WHERE pedal_id = :pedal_id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':pedal_id', $pedalID);
            $stmt->execute();
            echo '<script>alert("Pedal deleted successfully!");</script>';
        } catch (PDOException $e) {
            echo "Database Error: " . $e->getMessage();
            exit();
        }
    }
}

// Fetch pedals inventory from the database
try {
    $sql = "SELECT * FROM pedals";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $pedals = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedals Inventory</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
        }
        .sidebar .sidebar-heading {
            padding: 20px;
            font-size: 1.5rem;
            text-align: center;
            font-weight: bold;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .sidebar ul li a:hover {
            background-color: #495057;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-heading">Staff Dashboard</div>
        <ul>
            <li><a href="page_staff.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="view_pending_requests.php"><i class="fas fa-clock"></i> Reservation Requests</a></li>
            <li><a href="view_instrument_requests.php"><i class="fas fa-clock"></i> Instruments Requests</a></li>
            <li><a href="view_pedals_requests.php"><i class="fas fa-clock"></i> Pedals Requests</a></li>
            <li><a href="view_accepted_requests.php"><i class="fas fa-check-circle"></i> Accepted Requests</a></li>
            <li><a href="view_Instruments_inventory.php"><i class="fas fa-guitar"></i> Instruments Inventory</a></li>
            <li><a href="view_pedals_inventory.php"><i class="fas fa-guitar"></i> Pedals Inventory</a></li>
        </ul>
        <form action="logout.php" method="POST" class="logout-btn">
            <button type="submit" name="logout" class="btn btn-danger btn-block"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </div>

    <div class="content">
        <h1 class="mb-4">Pedals Inventory</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Pedal ID</th>
                    <th>Pedal Name</th>
                    <th>Brand</th>
                    <th>Condition</th>
                    <th>Availability</th>
                    <th>Rental Price</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pedals as $pedal): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($pedal['pedal_id']); ?></td>
                        <td>
                            <form action="view_pedals_inventory.php" method="POST" style="display:inline;">
                                <input type="hidden" name="pedal_id" value="<?php echo htmlspecialchars($pedal['pedal_id']); ?>">
                                <input type="text" name="pedal_name" value="<?php echo htmlspecialchars($pedal['pedal_name']); ?>" class="form-control" required>
                        </td>
                        <td><?php echo htmlspecialchars($pedal['brand']); ?></td>
                        <td><?php echo htmlspecialchars($pedal['condition']); ?></td>
                        <td>
                            <select name="availability_status" class="form-control" required>
                                <option value="available" <?php echo $pedal['availability_status'] == 'available' ? 'selected' : ''; ?>>Available</option>
                                <option value="unavailable" <?php echo $pedal['availability_status'] == 'unavailable' ? 'selected' : ''; ?>>Unavailable</option>
                            </select>
                        </td>
                        <td>
                            <input type="text" name="rental_price" value="<?php echo number_format($pedal['rental_price'], 2); ?>" class="form-control" required>
                        </td>
                        <td>
                            <span><?php echo htmlspecialchars($pedal['description']); ?></span> <!-- Display only, not editable -->
                        </td>
                        <td>
                            <button type="submit" name="update_pedal" class="btn btn-primary btn-sm">Update</button>
                            </form>
                            <form action="view_pedals_inventory.php" method="POST" style="display:inline;">
                                <input type="hidden" name="pedal_id" value="<?php echo htmlspecialchars($pedal['pedal_id']); ?>">
                                <button type="submit" name="delete_pedal" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this pedal?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
