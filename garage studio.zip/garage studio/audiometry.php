<?php
// Start the session
session_start();

// Include your database connection file
include 'connection_cust.php';

// Check if the user is logged in by checking the session variable
if (!isset($_SESSION['uUserID'])) {
    die('You need to login first.');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audio Effect Processor</title>
    <style>
        body {
            background-color: #121212; /* Dark background */
            color: white; /* White text for contrast */
            font-family: Arial, sans-serif; /* Font style */
            display: flex;
            flex-direction: column;
            align-items: center; /* Center content horizontally */
        }

        #logo {
            width: 200px; /* Adjust logo size */
            margin: 20px 0; /* Space around logo */
        }

        h1 {
            margin: 20px 0; /* Space around heading */
        }

        select {
            margin: 10px 0; /* Margin for spacing */
            padding: 5px; /* Padding for comfort */
            border-radius: 5px; /* Rounded corners */
            border: 1px solid #555; /* Border styling */
            background-color: #1e1e1e; /* Darker background for inputs */
            color: white; /* White text for inputs */
        }

        audio {
            margin: 20px 0; /* Space above audio player */
            background-color: #1e1e1e; /* Dark background for audio player */
            border-radius: 5px; /* Rounded corners */
            width: 300px; /* Width for the audio player */
        }

        .pedals-container {
            display: flex; /* Flexbox for horizontal layout */
            justify-content: center; /* Center pedals horizontally */
            flex-wrap: wrap; /* Allow wrapping to the next line */
            margin-top: 20px; /* Space above pedals */
        }

        .pedal {
            margin: 10px; /* Space between pedals */
            text-align: center; /* Center text under icons */
            width: 120px; /* Fixed width for each pedal */
            position: relative; /* For hover effects */
        }

        .pedal-icon {
            width: 140px; /* Set icon size (increased) */
            height: 140px; /* Set icon size (increased) */
            margin-bottom: 5px; /* Space between icon and label */
            cursor: pointer; /* Change cursor to pointer on hover */
            transition: transform 0.2s, filter 0.2s; /* Smooth scaling and filter change */
        }

        .pedal-icon:hover {
            transform: scale(1.1); /* Scale up on hover */
            filter: drop-shadow(0 0 10px rgba(255, 255, 255, 0.8)); /* Glow effect */
        }

        .pedal.active .pedal-icon {
            filter: drop-shadow(0 0 15px rgba(255, 255, 0, 1)); /* Glow when active */
        }

        .slider {
            width: 100%; /* Full width for sliders */
            margin: 5px 0; /* Margin for spacing */
        }


        .back-button {
            background-color: #ff5722;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            text-align: center;
            cursor: pointer;
            margin-top: 20px;
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            font-size: 16px;
        }

        .back-button:hover {
            background-color: #e64a19;
        }
    </style>
</head>
<body>
    <img id="logo" src="srcpedals/logo.png" alt="Logo"> <!-- Logo Image -->

    <h1>Select a song and apply effects</h1>

    <label for="trackSelect">Choose a Track:</label>
    <select id="trackSelect">
        <option value="songs/acoustic.mp3">Track 1 - Acoustic</option>
        <option value="songs/electric.mp3">Track 2 - Electric</option>
        <option value="songs/bassfrank.mp3">Track 3 - Bass</option>
        <option value="songs/slow.mp3">Acoustic - Slow Dancing in a Burning room</option>
        <option value="songs/redbone.mp3">Acoustic - Redbone</option>
        <option value="songs/sosick.mp3">Acoustic - so sick</option>
        <option value="songs/guitarlucky.mp3">Electric - Get Lucky</option>
        <option value="songs/guitarpasilyo.mp3">Electric - Pasilyo</option>
        <option value="songs/guitartreasure.mp3">Electric - Treasure</option>
        <option value="songs/guitarwind.mp3">Electric - September</option>
        <option value="songs/starship.mp3">Electric - Starship</option>
        <option value="songs/bassbird.mp3">Bass - Birds of a Feather</option>
        <option value="songs/basshey.mp3">Bass - Hey Barbara</option>
        <option value="songs/bassjean.mp3">Bass - Billie Jean</option>
        <option value="songs/bassputh.mp3">Bass- Attention</option>
        <option value="songs/bassfloor.mp3">Track 3 - Get on the Floor</option>
    </select>

    <h2>Audio</h2>
    <audio id="audioPlayer" controls></audio>

    <h3>Toggle Effects and Adjust</h3>

    <div class="pedals-container">
        <div class="pedal">
            <label>
                <img class="pedal-icon" src="srcpedals/guitar1.png" alt="Reverb Icon">
                <input type="checkbox" id="reverb"> Reverb
            </label>
            <input class="slider" type="range" id="reverbDecay" min="0" max="10" step="0.1" value="2" disabled> Decay
        </div>

        <div class="pedal">
            <label>
                <img class="pedal-icon" src="srcpedals/guitar2.png" alt="Delay Icon">
                <input type="checkbox" id="delay"> Delay
            </label>
            <input class="slider" type="range" id="delayTime" min="0" max="1" step="0.05" value="0.2" disabled> Delay Time
        </div>

        <div class="pedal">
            <label>
                <img class="pedal-icon" src="srcpedals/guitar3.png" alt="Phaser Icon">
                <input type="checkbox" id="phaser"> Phaser
            </label>
            <input class="slider" type="range" id="phaserFrequency" min="0" max="10" step="0.1" value="1" disabled> Frequency
        </div>

        <div class="pedal">
            <label>
                <img class="pedal-icon" src="srcpedals/guitar4.png" alt="Compressor Icon">
                <input type="checkbox" id="compressor"> Compressor
            </label>
            <input class="slider" type="range" id="compressorThreshold" min="-100" max="0" step="1" value="-24" disabled> Threshold
        </div>

        <div class="pedal">
            <label>
                <img class="pedal-icon" src="srcpedals/guitar5.png" alt="Distortion Icon">
                <input type="checkbox" id="distortion"> Distortion
            </label>
            <input class="slider" type="range" id="distortionAmount" min="0" max="1" step="0.01" value="0.2" disabled> Amount
        </div>

        <div class="pedal">
            <label>
                <img class="pedal-icon" src="srcpedals/guitar6.png" alt="Chorus Icon">
                <input type="checkbox" id="chorus"> Chorus
            </label>
            <input class="slider" type="range" id="chorusDepth" min="0" max="1" step="0.05" value="0.5" disabled> Depth
        </div>
    </div>

    <hr>
    <button class="back-button" onclick="window.location.href='customer_page.php';">Back to Customer Page</button>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/tone/14.8.35/Tone.min.js"></script>
    <script>
        const audioPlayer = document.getElementById('audioPlayer');
        const trackSelect = document.getElementById('trackSelect');

        let player, reverb, delay, phaser, compressor, distortion, chorus;

        // Function to load the selected track
        function loadTrack(track) {
            const fileURL = track; // Use the value directly from the dropdown
            audioPlayer.src = fileURL;

            if (player) player.dispose(); // Dispose previous player if it exists

            // Create a new player and chain it to the effects
            player = new Tone.Player(fileURL, () => {
                console.log("Audio loaded");
            }).toDestination(); // Send directly to destination, we'll adjust this later

            // Setup initial effects
            reverb = new Tone.Reverb({ decay: 2 }).toDestination();
            delay = new Tone.FeedbackDelay(0.2).toDestination();
            phaser = new Tone.Phaser({ frequency: 1 }).toDestination();
            compressor = new Tone.Compressor({ threshold: -24 }).toDestination();
            distortion = new Tone.Distortion(0).toDestination();
            chorus = new Tone.Chorus({ depth: 0.5 }).toDestination();

            // Connect the player to the effect chain
            player.connect(Tone.Destination);
        }

        // Load the initial track
        loadTrack(trackSelect.value);

        // Change track when selected from dropdown
        trackSelect.addEventListener('change', function() {
            loadTrack(this.value);
        });

        // Enable sliders when an effect is selected
        function enableSlider(effectCheckbox, sliderId) {
            const slider = document.getElementById(sliderId);
            slider.disabled = !effectCheckbox.checked;
        }

        // Toggle Reverb
        document.getElementById('reverb').addEventListener('change', function() {
            enableSlider(this, 'reverbDecay');
            if (this.checked) {
                player.connect(reverb);
            } else {
                player.disconnect(reverb);
            }
        });
        document.getElementById('reverbDecay').addEventListener('input', function() {
            reverb.decay = parseFloat(this.value);
        });

        // Toggle Delay
        document.getElementById('delay').addEventListener('change', function() {
            enableSlider(this, 'delayTime');
            if (this.checked) {
                player.connect(delay);
            } else {
                player.disconnect(delay);
            }
        });
        document.getElementById('delayTime').addEventListener('input', function() {
            delay.delayTime.value = parseFloat(this.value);
        });

        // Toggle Phaser
        document.getElementById('phaser').addEventListener('change', function() {
            enableSlider(this, 'phaserFrequency');
            if (this.checked) {
                player.connect(phaser);
            } else {
                player.disconnect(phaser);
            }
        });
        document.getElementById('phaserFrequency').addEventListener('input', function() {
            phaser.frequency.value = parseFloat(this.value);
        });

        // Toggle Compressor
        document.getElementById('compressor').addEventListener('change', function() {
            enableSlider(this, 'compressorThreshold');
            if (this.checked) {
                player.connect(compressor);
            } else {
                player.disconnect(compressor);
            }
        });
        document.getElementById('compressorThreshold').addEventListener('input', function() {
            compressor.threshold.value = parseFloat(this.value);
        });

        // Toggle Distortion
        document.getElementById('distortion').addEventListener('change', function() {
            enableSlider(this, 'distortionAmount');
            if (this.checked) {
                player.connect(distortion);
            } else {
                player.disconnect(distortion);
            }
        });
        document.getElementById('distortionAmount').addEventListener('input', function() {
            distortion.distortion = parseFloat(this.value);
        });

        // Toggle Chorus
        document.getElementById('chorus').addEventListener('change', function() {
            enableSlider(this, 'chorusDepth');
            if (this.checked) {
                player.connect(chorus);
            } else {
                player.disconnect(chorus);
            }
        });
        document.getElementById('chorusDepth').addEventListener('input', function() {
            chorus.depth = parseFloat(this.value);
        });

        // Ensure the audio context starts only when the play button is pressed
        audioPlayer.addEventListener('play', () => {
            if (Tone.context.state !== 'running') {
                Tone.context.resume();
            }
            player.start();
        });

        // Stop the audio when the HTML5 audio element pauses
        audioPlayer.addEventListener('pause', () => {
            player.stop();
        });
    </script>
</body>
</html>