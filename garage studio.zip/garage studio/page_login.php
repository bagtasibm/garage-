

<!doctype html>
<html lang="en" data-bs-theme="auto">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Garage Music Studio</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container-fluid {
            height: 100vh;
            display: flex;
        }

        /* Left Section - Form */
        .left-side {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 40px;
            background-color: #fff;
            max-width: 500px; /* Limit the width of the form */
            margin: auto; /* Center the form */
            border-radius: 8px; /* Optional: Add rounded corners */
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); /* Optional: Add a shadow for visual effect */
        }

        /* Right Section - Background Image */
        .right-side {
            background-image: url('img/loginpage.png'); /* Change to your image path */
            background-size: cover;
            background-position: center;
        }

        .form-floating {
            margin-bottom: 20px;
        }

        .error-message {
            color: red;
            font-size: 0.85em;
        }

        .login-title {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 1rem;
        }

        .logo {
            display: block;
            margin: 0 auto 1.5rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Left Side: Login Form -->
        <div class="col-md-6 left-side">
            <main class="form-signin w-100 m-auto">
                <form action="process_login.php" method="post">
                    <img class="logo mb-4" src="img/garagelogo.png" alt="" width="150" height="150">
                    <h1 class="h3 mb-3 fw-normal text-center">Welcome to Garage Music Studio</h1>
                    <p class="text-center">Sign in to your account</p>

                    <div class="form-floating">
                        <!-- PHP to keep email value on error -->
                        <input type="email" class="form-control" id="floatingInput" name="email" placeholder="Email Address" required pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" title="Ex. name@gmail.com" value="<?php echo isset($_GET['email']) ? htmlspecialchars($_GET['email']) : ''; ?>">
                        <label for="floatingInput">Email address</label>
                    </div>

                    <div class="form-floating">
                        <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Password">
                        <label for="floatingPassword">Password</label>
                        <div class="form-check mt-2">
                            <input class="form-check-input" type="checkbox" onclick="togglePasswordVisibility('floatingPassword')">
                            <label class="form-check-label" for="showPassword">SHOW PASSWORD</label>
                        </div>
                    </div>

                    <!-- Display error message if exists -->
                    <?php if (isset($_GET['error'])): ?>
                        <div class="error-message"><?php echo htmlspecialchars($_GET['error']); ?></div>
                    <?php endif; ?>

                    <button class="btn btn-primary w-100 py-2" type="submit">Sign in</button>
                    
                    <div class="mt-3 text-center">
                        <a href="process_forgotpass.php">Forgot your password?</a>
                    </div>
                    <div class="mt-3 text-center">
                        <a href="page_register.php">Don't have an account yet?</a>
                    </div>
                </form>
            </main>
        </div>

        <!-- Right Side: Background Image -->
        <div class="col-md-6 right-side"></div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePasswordVisibility(passwordFieldId) {
            var passwordField = document.getElementById(passwordFieldId);
            if (passwordField.type === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }
    </script>
</body>
</html>