<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>My Music Studio</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap JS (Bundle includes Popper.js) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>

    <!-- Navigation Bar -->
    <header>
        <nav class="centered-nav">
            <div class="logo">
                <center><img src="img/garagelogo.png" alt="Music Studio Logo" width="200" ></center>
            </div>
            <ul class="nav-links">
                <li><a href="audiometry.php">Audiometry</a></li>
                <li><a href="">|</a></li>
                <li><a href="#studios">Studio</a></li>
                <li><a href="">|</a></li>
                <li><a href="#customers">Customers</a></li>
                <li><a href="">|</a></li>
                <li><a href="#what-we-do">What We Do</a></li>
                <li><a href="">|</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="">|</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
    </header>
    <!-- Hero Section with Live Background Video --> 
    <section id="hero">
        <!-- Background video -->
        <video autoplay muted loop id="bg-video">
            <source src="vid/garagestudio.mp4" type="video/mp4">
            Your browser does not support HTML5 video.
        </video>

        <!-- Hero Content -->
        <div class="hero-content">
            <h1>Garage Music Studio</h1>
            <p>A world-class recording studio in the heart of Malolos, Bulacan!</p><br>

            <div class="hero-buttons">
                <h3><a href="page_login.php" class="button">Login / sign up</a></h3>
            </div>
        </div>
    </section>

    <!-- Studios Section -->
    <section id="studios">
    <h2>Our Studio</h2>
    <div class="studio-cards">
        <!-- Live Room -->
        <div class="studio-card">
            <div id="liveRoomCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <!--<div class="carousel-item active">
                        <img src="img/guitars.png" class="d-block w-100" alt="Live Room 1" style="height: 500px;">
                    </div> -->
                    <div class="carousel-item">
                        <img src="img/live/live0.png" class="d-block w-100" alt="Live Room 2" style="height: 500px;">
                    </div>
                    <div class="carousel-item active">
                        <img src="img/live/live3.png" class="d-block w-100" alt="Live Room 3" style="height: 500px;">
                    </div>
                    <div class="carousel-item active">
                        <img src="img/live/live4.png" class="d-block w-100" alt="Live Room 4" style="height: 500px;">
                    </div>
                    
                    
                    <!-- Add more images for the Live Room here -->
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#liveRoomCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#liveRoomCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
            <h3>Live Room</h3>
            <p>Our live room offers phenomenal acoustics for drums, grand piano, and string ensembles.</p>
        </div>

        <!-- Instruments -->
        <div class="studio-card">
            <div id="instrumentsCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/instrument/guitars.png" class="d-block w-100" alt="Instrument 1" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/instrument/guitar7.png" class="d-block w-100" alt="Instrument 7" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/instrument/guitar2.png" class="d-block w-100" alt="Instrument 2" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/instrument/guitar3.png" class="d-block w-100" alt="Instrument 3" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/instrument/guitar4.png" class="d-block w-100" alt="Instrument 4" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/instrument/guitar5.png" class="d-block w-100" alt="Instrument 5" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/instrument/guitar6.png" class="d-block w-100" alt="Instrument 6" style="height: 500px;">
                    </div>
                    <!-- Add more images for the Instruments here -->
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#instrumentsCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#instrumentsCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
            <h3>Instruments</h3>
            <p>Our main recording and mix facility, equipped with the finest technology for superior sound.</p>
        </div>

        <!-- Guitar Pedals -->
        <div class="studio-card">
            <div id="pedalsCarousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/pedals.png" class="d-block w-100" alt="Pedal 1" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/pedals/pedals1.png" class="d-block w-100" alt="Pedal 2" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/pedals/pedals4.png" class="d-block w-100" alt="Pedal 2" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/pedals/pedals3.png" class="d-block w-100" alt="Pedal 3" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/pedals/pedals2.png" class="d-block w-100" alt="Pedal 4" style="height: 500px;">
                    </div>
                    <!-- Add more images for the Pedals here -->
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#pedalsCarousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#pedalsCarousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
            <h3>Guitar Pedals</h3>
            <p>Perfect for modern music production with advanced systems and synths.</p>
        </div>
    </div>
</section>


<!-- Customers Section -->
<!-- Customers Section -->
<section id="customers">
    <center><h2>Our Customers</h2></center>
    <div class="studio-cards">
        <!-- Customer 1 -->
        <div class="studio-card">
            <div id="customer1Carousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/customer/1.jpg" class="d-block w-100" alt="Customer 1 - Image 1" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/2.jpg" class="d-block w-100" alt="Customer 1 - Image 2" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/3.jpg" class="d-block w-100" alt="Customer 1 - Image 3" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/4.jpg" class="d-block w-100" alt="Customer 1 - Image 4" style="height: 500px;">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#customer1Carousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#customer1Carousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
            <h3>Customer 1</h3>
            <p>Description of Customer 1's experience or testimonial.</p>
        </div>

        <!-- Customer 2 -->
        <div class="studio-card">
            <div id="customer2Carousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/customer/5.jpg" class="d-block w-100" alt="Customer 2 - Image 1" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/6.jpg" class="d-block w-100" alt="Customer 2 - Image 2" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/7.jpg" class="d-block w-100" alt="Customer 2 - Image 3" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/8.jpg" class="d-block w-100" alt="Customer 2 - Image 4" style="height: 500px;">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#customer2Carousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#customer2Carousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
            <h3>Customer 2</h3>
            <p>Description of Customer 2's experience or testimonial.</p>
        </div>

        <!-- Customer 3 -->
        <div class="studio-card">
            <div id="customer3Carousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="img/customer/9.jpg" class="d-block w-100" alt="Customer 3 - Image 1" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/10.jpg" class="d-block w-100" alt="Customer 3 - Image 2" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/11.jpg" class="d-block w-100" alt="Customer 3 - Image 3" style="height: 500px;">
                    </div>
                    <div class="carousel-item">
                        <img src="img/customer/12.jpg" class="d-block w-100" alt="Customer 3 - Image 4" style="height: 500px;">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#customer3Carousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#customer3Carousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
            <h3>Customer 3</h3>
            <p>Description of Customer 3's experience or testimonial.</p>
        </div>
    </div>
</section>



    <!-- Services Section (First What We Do Section) -->
    <section id="what-we-do">
        <div class="image-container">
            <img src="img/watwedo.png" alt="What We Do Image" style="width: 1800px; height: 300px">
            <h2 class="overlay-heading">What We Do</h2><br>
        </div>
        <div class="services">
            <div class="service">
                <h3>Renting a Studio</h3><br>
                <p>You can book our studio for your recording sessions, giving you access to high-quality equipment and a professional environment to create your music.</p>
            </div>
            <div class="service">
                <h3>Instrument Rentals</h3><br>
                <p>You can rent instruments from our studio or offer your own for others to rent, providing musicians with a wide range of gear to choose from.</p>
            </div>
            <div class="service">
                <h3>Audiometry</h3><br>
                <p>Lets you demo your own guitars and pedals with the music of your choice, giving you full creative control over your sound.</p>
            </div>
        </div>
    </section>

    <!-- Second What We Do Section (New Section) -->
     <br>
     <section id="about">
        <div class="image-container">
        <center><img src="img/watwedo.png" alt="What We Do Image" style="width: 1800px; height: 300px"></center>
            <h2 class="overlay-heading">About</h2><br>
        </div>
        <div class="services">
            <div class="service">
                <h3>Official Page</h3><br>
                <a href="https://www.facebook.com/garagemusicstudio">facebook.com/garagemusicstudio</a><br>
                <a href="https://shopee.ph/garagemusicstore">shopee.ph/garagemusicstore</a>
            </div>
            <div class="service">
                <h3>Phone Number</h3><br>
                <p>0919-096-4782</p>
            </div>
            <div class="service">
                <h3>Location</h3><br>
                <a href="https://www.google.com/maps/dir/?api=1&destination=14.8747447%2C120.8237686">74 Purok 2, Paseo de Mabini, Malolos, Philippines</a>
                <p></p>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Garage Music Studio. All rights reserved.</p>
    </footer>

</body>
</html>
