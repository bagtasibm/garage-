<?php
// Autoload PHPMailer classes using Composer
require 'PHPMailer/PHPMailer/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once 'connection_cust.php'; // Include your database connection

// Check if user is logged in and has appropriate access level (e.g., level 3 for staff)
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 3) {
    header('Location: page_login.php');
    exit();
}

// Handle accept/reject actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $requestID = $_POST['requestID'];
    $action = $_POST['action']; // 'accept' or 'reject'

    // Fetch user email, name, pedal details, and price
    $sqlUser = "SELECT user_pedals.uUserID, user_pedals.pedal_name, user_pedals.model, 
                       user_pedals.description, user_pedals.images, user_pedals.price, 
                       CONCAT(users.uFName, ' ', users.uLName) AS full_name, users.uEmail
                FROM user_pedals 
                JOIN users ON user_pedals.uUserID = users.uUserID 
                WHERE user_pedals.id = :requestID AND user_pedals.status = 'pending'";
    $stmtUser = $pdo->prepare($sqlUser);
    $stmtUser->bindParam(':requestID', $requestID);
    $stmtUser->execute();
    $userData = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if ($userData) {
        $userEmail = $userData['uEmail'];
        $userName = $userData['full_name'];
        $pedalName = $userData['pedal_name'];
        $model = $userData['model'];
        $description = $userData['description'];
        $images = $userData['images'];
        $rentalPrice = $userData['price']; // Get the rental price from the `user_pedals` table

        if ($action == 'accept') {
            // Check if the pedal already exists in the pedals table to avoid duplication
            $checkSql = "SELECT COUNT(*) FROM pedals WHERE pedal_name = :pedal_name AND brand = :model";
            $checkStmt = $pdo->prepare($checkSql);
            $checkStmt->bindParam(':pedal_name', $pedalName);
            $checkStmt->bindParam(':model', $model);
            $checkStmt->execute();
            $exists = $checkStmt->fetchColumn();
            
            if ($exists == 0) {
                // Insert the pedal into the pedals table
                $sql = "INSERT INTO pedals (pedal_name, pedal_type, brand, `condition`, availability_status, description, rental_price, created_at) 
                        VALUES (:pedal_name, 'Unknown', :model, 'Good', 'available', :description, :rental_price, CURRENT_TIMESTAMP)";
                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':pedal_name', $pedalName);
                $stmt->bindParam(':model', $model);
                $stmt->bindParam(':description', $description);
                $stmt->bindParam(':rental_price', $rentalPrice);
            
                if ($stmt->execute()) {
                    // After inserting, update the status to accepted
                    $updateSql = "UPDATE user_pedals SET status = 'accepted' WHERE id = :requestID";
                    $updateStmt = $pdo->prepare($updateSql);
                    $updateStmt->bindParam(':requestID', $requestID);
                    $updateStmt->execute();
                
                    // Define the subject and message for the accepted request
                    $subject = "Pedal Request Accepted";
                    $message = "Dear $userName, \n\nYour pedal request for $pedalName has been accepted and added to our inventory. Thank you!";
                }
            } else {
                echo '<div class="alert alert-warning">This pedal already exists in the inventory.</div>';
                return; // Add return here to prevent further execution
            }
        } elseif ($action == 'reject') {
            // Update the status to rejected
            $sql = "UPDATE user_pedals SET status = 'rejected' WHERE id = :requestID";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':requestID', $requestID);
            $stmt->execute();
        
            // Define the subject and message for the rejected request
            $subject = "Pedal Request Rejected";
            $message = "Dear $userName, \n\nWe regret to inform you that your pedal request for $pedalName has been rejected.";
        }

        // Only send email if a single insert or update occurred
        if (!isset($exists) || $exists == 0) {
            // Send email to the user
            $mail = new PHPMailer(true);
            try {
                // SMTP settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'zerovstore@gmail.com';  // Your Gmail
                $mail->Password   = 'fxqe wqwy silt ysln';         // Your Gmail password or app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;
        
                // Email content
                $mail->setFrom('GarageMusicStudio@gmail.com', 'Garage Music Studio Staff');
                $mail->addAddress($userEmail, $userName);
                $mail->isHTML(false);
                $mail->Subject = $subject;
                $mail->Body    = $message;
        
                $mail->send();
                echo '<div class="alert alert-success">Request successfully ' . $action . 'ed and email notification sent to the user.</div>';
            } catch (Exception $e) {
                echo '<div class="alert alert-warning">Request ' . $action . 'ed, but email could not be sent. Mailer Error: ' . $mail->ErrorInfo . '</div>';
            }

            // Log the action to the audituser table
            $audit_sql = "INSERT INTO audituser (aAction, aTimestamp, uUserID) VALUES (:action, CURRENT_TIMESTAMP, :uUserID)";
            $audit_stmt = $pdo->prepare($audit_sql);
            $audit_action = ucfirst($action) . "ed pedal request ID: " . $requestID;
            $audit_stmt->bindParam(':action', $audit_action);
            $audit_stmt->bindParam(':uUserID', $_SESSION['uUserID']); // Store the staff member's user ID who performed the action
            $audit_stmt->execute();
        }
    } else {
        echo '<div class="alert alert-danger">Failed to retrieve user details. Please try again.</div>';
    }
}

// Fetch pending pedal requests with user names
try {
    $sql = "SELECT user_pedals.*, CONCAT(users.uFName, ' ', users.uLName) AS full_name 
            FROM user_pedals 
            JOIN users ON user_pedals.uUserID = users.uUserID 
            WHERE user_pedals.status = 'pending'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $pendingRequests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Pedal Requests</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
        }
        .sidebar .sidebar-heading {
            padding: 20px;
            font-size: 1.5rem;
            text-align: center;
            font-weight: bold;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .sidebar ul li a:hover {
            background-color: #495057;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
        }
    </style>
    <script>
        // Function to confirm the action
        function confirmAction(action) {
            return confirm('Are you sure you want to ' + action + ' this request?');
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-heading">Staff Dashboard</div>
        <ul>
            <li><a href="page_staff.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="view_pending_requests.php"><i class="fas fa-clock"></i> Reservation Requests</a></li>
            <li><a href="view_instrument_requests.php"><i class="fas fa-clock"></i> Instruments Requests</a></li>
            <li><a href="view_pedals_requests.php"><i class="fas fa-clock"></i> Pedals Requests</a></li>
            <li><a href="view_accepted_requests.php"><i class="fas fa-check-circle"></i> Accepted Requests</a></li>
            <li><a href="view_Instruments_inventory.php"><i class="fas fa-guitar"></i> Instruments Inventory</a></li>
            <li><a href="view_pedals_inventory.php"><i class="fas fa-guitar"></i> pedals Inventory</a></li>
        </ul>
        <form action="logout.php" method="POST" class="logout-btn">
            <button type="submit" name="logout" class="btn btn-danger btn-block"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </div>

    <div class="content">
        <h2 class="text-center">Pending Pedal Requests</h2>
        <?php if (count($pendingRequests) > 0): ?>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>User Name</th>
                        <th>Pedal Name</th>
                        <th>Model</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pendingRequests as $request): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($request['id']); ?></td>
                            <td><?php echo htmlspecialchars($request['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['pedal_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['model']); ?></td>
                            <td><?php echo htmlspecialchars($request['description']); ?></td>
                            <td>
                                <form method="POST" action="view_pedals_requests.php">
                                    <input type="hidden" name="requestID" value="<?php echo $request['id']; ?>">
                                    <button type="submit" name="action" value="accept" class="btn btn-success btn-sm" onclick="return confirmAction('accept');">Accept</button>
                                    <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm" onclick="return confirmAction('reject');">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-info">No pending requests at this time.</div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
