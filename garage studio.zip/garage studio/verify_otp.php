<?php
session_start();

// Initialize an error message variable
$error_message = "";

// Check if OTP form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get OTP from the form
    $enteredOtp = $_POST['otp'];

    // Check if OTP matches the one stored in session
    if (isset($_SESSION['resetOtp']) && $enteredOtp == $_SESSION['resetOtp']) {
        // OTP is valid, redirect to change password page
        echo '<script>alert("OTP verified successfully! You can now change your password."); window.location.href = "process_change_password.php";</script>';
        exit();
    } else {
        // OTP is invalid, set the error message
        $error_message = "Invalid OTP! Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP - Garage Music Studio</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container-fluid {
            height: 100vh;
            display: flex;
        }

        /* Left Section - Form */
        .left-side {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 40px;
            background-color: #fff;
            max-width: 500px; /* Limit the width of the form */
            margin: auto; /* Center the form */
            border-radius: 8px; /* Add rounded corners */
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); /* Add a shadow for visual effect */
        }

        /* Right Section - Background Image */
        .right-side {
            background-image: url('img/loginpage.png'); /* Change to your image path */
            background-size: cover;
            background-position: center;
        }

        .form-floating {
            margin-bottom: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo {
            display: block;
            margin: 0 auto 1.5rem;
        }

        .alert-danger {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Left Side: OTP Verification Form -->
        <div class="col-md-6 left-side">
            <div class="otp-verification-container w-100 m-auto">
                <center><img class="logo mb-4" src="img/garagelogo.png" alt="Logo" width="150" height="150"></center>
                <h2>Verify OTP</h2>
                <form action="verify_otp.php" method="POST">
                    <div class="form-group">
                        <label for="otp">Enter OTP Code</label>
                        <input type="text" class="form-control" id="otp" name="otp" placeholder="Enter the OTP sent to your email" required pattern="^\d{6}$" title="Please enter a 6-digit OTP" maxlength="6" oninput="validateNumericInput(this)">
                    </div>

                    <!-- Display the error message below OTP input if it exists -->
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary w-100">Verify OTP</button>
                </form>
            </div>
        </div>

        <!-- Right Side: Background Image -->
        <div class="col-md-6 right-side"></div>
    </div>

    <!-- Bootstrap JS Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Function to restrict input to only numbers
        function validateNumericInput(input) {
            input.value = input.value.replace(/[^0-9]/g, ''); // Remove any non-numeric characters
        }
    </script>
</body>
</html>