<?php
// Start the session
session_start();

// Include your database connection file
include 'connection_cust.php';

// Check if the user is logged in by checking the session variable
if (!isset($_SESSION['uUserID'])) {
    die('You need to login first to make a request.');
}

// Get the logged-in user's first name and user ID from the session
$uUserID = $_SESSION['uUserID'];       // Using uUserID (matching the users table)
$user_fname = $_SESSION['user_fname']; // Using user_fname

// Fixed price for the instrument
$price = 100;  // Fixed price of 100 for the guitar

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Get form data (using PDO's prepared statements for security)
    $instrument_name = $_POST['instrument_name'];
    $model = $_POST['model'];
    $description = $_POST['description'];

    // Create a directory for the user if it doesn't exist
    $user_dir = "instruments/" . $user_fname . "/";
    if (!is_dir($user_dir)) {
        mkdir($user_dir, 0777, true);
    }

    // Handle multiple images
    $image_count = count($_FILES['images']['name']);
    $uploaded_images = [];

    for ($i = 0; $i < $image_count; $i++) {
        $image_name = basename($_FILES['images']['name'][$i]);
        $target_file = $user_dir . $image_name;
        
        // Move uploaded file to the user's directory
        if (move_uploaded_file($_FILES['images']['tmp_name'][$i], $target_file)) {
            $uploaded_images[] = $image_name;
        }
    }

    // Convert the array of uploaded images to a comma-separated string
    $images = implode(",", $uploaded_images);

    // Insert the instrument data into the database using PDO
    $sql = "INSERT INTO user_instruments (instrument_name, model, description, images, price, uUserID)
            VALUES (:instrument_name, :model, :description, :images, :price, :uUserID)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':instrument_name', $instrument_name);
    $stmt->bindParam(':model', $model);
    $stmt->bindParam(':description', $description);
    $stmt->bindParam(':images', $images);
    $stmt->bindParam(':price', $price);  // Binding the fixed price
    $stmt->bindParam(':uUserID', $uUserID);

    if ($stmt->execute()) {
        // Set a success message in session
        $_SESSION['success_message'] = "Your instrument request has been submitted!";
        // Redirect to the same page to show the message
        header("Location: rent_instrument.php");
        exit(); // Always call exit after a header redirection
    } else {
        echo "Error: Could not submit your request.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent Your Instrument</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: #000000; /* Black background for the entire page */
            font-family: Arial, sans-serif;
            color: #ffffff; /* White text for better contrast */
        }
        .container {
            margin-top: 50px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .rent-container {
            background-color: #333333; /* Dark grey background */
            color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.5);
            width: 400px;
            text-align: center;
        }
        h2 {
            color: #f0f0f0; /* Slightly lighter color for the heading */
            text-align: center;
            margin-bottom: 20px;
        }
        .message-success {
            background-color: #28a745; /* Green background for success message */
            color: #ffffff;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        label {
            color: #ffffff; /* White label text */
        }
        .form-control {
            background-color: #444444; /* Darker input field */
            color: #ffffff;
            border: none;
            padding: 10px;
        }
        .form-control:focus {
            background-color: #555555; /* Lighter dark on focus */
            color: #ffffff;
        }
        .btn-primary {
            background-color: #ff4500; /* Orange button */
            border-color: #ff4500;
            padding: 10px 20px;
            font-size: 16px;
            width: 100%;
            margin-top: 20px;
            color: #ffffff; /* White text color */
        }

        .btn-primary:hover {
            background-color: #ff6347; /* Lighter orange on hover */
            border-color: #ff6347;
            color: #ffffff; /* Keep white text on hover */
        }

        .btn-back {
            background-color: #ff4500; /* Same color as Submit button */
            border-color: #ff4500;
            padding: 10px 20px;
            font-size: 16px;
            width: 100%;
            margin-top: 10px; /* Some margin to separate from the Submit button */
            color: #ffffff; /* White text color */
        }

        .btn-back:hover {
            background-color: #ff6347; /* Lighter orange on hover */
            border-color: #ff6347;
            color: #ffffff; /* Keep white text on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="rent-container">
            <!-- Check for success message in session and display it -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="message-success">
                    <?php echo $_SESSION['success_message']; ?>
                    <?php unset($_SESSION['success_message']); // Clear the message ?>
                </div>
            <?php endif; ?>
            
            <h2>Rent Your Instrument</h2>
            <form action="rent_instrument.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="instrument_name">Instrument Name:</label>
                    <input type="text" class="form-control" id="instrument_name" name="instrument_name" required>
                </div>
                <div class="form-group">
                    <label for="model">Model:</label>
                    <input type="text" class="form-control" id="model" name="model" required>
                </div>
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label for="images">Upload Images of Your Instrument (multiple allowed):</label>
                    <input type="file" class="form-control" id="images" name="images[]" accept="image/*" multiple required>
                </div>
                <input type="submit" class="btn btn-primary" name="submit" value="Submit">
            </form>
            
            <!-- Back Button -->
            <button class="btn btn-back" onclick="window.location.href='customer_page.php';">Back to Customer Page</button>
        </div>
    </div>
</body>
</html>



