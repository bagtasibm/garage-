<?php
session_start();
require_once 'connection_cust.php'; // Include your database connection
require_once('tcpdf/tcpdf.php'); // Include TCPDF library

// Check if user is logged in and has appropriate access level
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 1) {
    header('Location: page_login.php');
    exit();
}

// Fetch audit log entries along with user name
try {
    $sql = "SELECT audituser.aAudID, audituser.aAction, audituser.aTimestamp, audituser.uUserID, users.uFName, users.uLName 
            FROM audituser
            JOIN users ON audituser.uUserID = users.uUserID
            ORDER BY audituser.aTimestamp DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $auditLogs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage();
    exit();
}

// Check if the PDF generation is requested
if (isset($_GET['download']) && $_GET['download'] == 'pdf') {
    // Create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // Set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Your Name');
    $pdf->SetTitle('Audit Log Report');
    $pdf->SetSubject('Audit Log');
    
    // Disable header and footer to avoid issues
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // Add a page
    $pdf->AddPage();

    // Set font
    $pdf->SetFont('helvetica', '', 12);

    // Create HTML content for the PDF
    $html = '<h2>Audit Log Report</h2>';
    $html .= '<table border="1" cellpadding="5">';
    $html .= '<thead>
                <tr>
                    <th>Audit ID</th>
                    <th>User Name</th>
                    <th>Action</th>
                    <th>Timestamp</th>
                </tr>
              </thead>';
    $html .= '<tbody>';
    foreach ($auditLogs as $log) {
        $html .= '<tr>';
        $html .= '<td>' . htmlspecialchars($log['aAudID']) . '</td>';
        $html .= '<td>' . htmlspecialchars($log['uFName'] . ' ' . $log['uLName']) . '</td>';
        $html .= '<td>' . htmlspecialchars($log['aAction']) . '</td>';
        $html .= '<td>' . htmlspecialchars($log['aTimestamp']) . '</td>';
        $html .= '</tr>';
    }
    $html .= '</tbody></table>';

    // Output the HTML content to the PDF
    $pdf->writeHTML($html, true, false, true, false, '');

    // Close and output PDF document
    $pdf->Output('audit_log_report.pdf', 'D'); // 'D' for download, 'I' for inline view

    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audit Log</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: 0 auto; /* Center the content */
        }
        #searchInput {
            max-width: 300px; /* Shorten the search input */
            display: inline-block;
        }
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="container">
            <h2 class="text-center">Audit Log</h2>

            <!-- Button to download PDF -->
            <a href="auditlog.php?download=pdf" class="btn btn-primary mb-4">Download PDF</a>

            <!-- Search bar for filtering the audit log -->
            <input type="text" id="searchInput" onkeyup="filterTable()" class="form-control mb-4" placeholder="Search for user name, action, or timestamp">

            <?php if (count($auditLogs) > 0): ?>
                <table class="table table-bordered mt-4" id="auditTable">
                    <thead>
                        <tr>
                            <th>Audit ID</th>
                            <th>User Name</th>
                            <th>Action</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($auditLogs as $log): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($log['aAudID']); ?></td>
                                <td><?php echo htmlspecialchars($log['uFName'] . ' ' . $log['uLName']); ?></td>
                                <td><?php echo htmlspecialchars($log['aAction']); ?></td>
                                <td><?php echo htmlspecialchars($log['aTimestamp']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-info">No audit log entries found.</div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function filterTable() {
            let input, filter, table, tr, td, i, txtValue;
            input = document.getElementById("searchInput");
            filter = input.value.toLowerCase();
            table = document.getElementById("auditTable");
            tr = table.getElementsByTagName("tr");

            for (i = 1; i < tr.length; i++) {
                tr[i].style.display = "none"; // Hide all rows by default

                td = tr[i].getElementsByTagName("td");
                for (let j = 0; j < td.length; j++) {
                    if (td[j]) {
                        txtValue = td[j].textContent || td[j].innerText;
                        if (txtValue.toLowerCase().indexOf(filter) > -1) {
                            tr[i].style.display = ""; // Show the row if a match is found
                            break; // Exit inner loop once a match is found
                        }
                    }
                }
            }
        }
    </script>
</body>
</html>
