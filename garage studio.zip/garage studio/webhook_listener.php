<?php
require 'vendor/autoload.php'; // Ensure Guzzle is correctly loaded
require_once 'connection_cust.php'; // Your database connection

// Get the raw payload from PayMongo
$payload = file_get_contents('php://input');
$headers = getallheaders();

// Log webhook payload for debugging (optional, useful for testing)
file_put_contents('webhook_log.txt', $payload, FILE_APPEND);

// Decode the JSON payload into an associative array
$event = json_decode($payload, true);

// Check if the webhook event is related to a successful payment
if (isset($event['data']['attributes']['type']) && $event['data']['attributes']['type'] == 'payment.paid') {
    // Get the payment intent ID from the webhook event
    $paymentIntentID = $event['data']['attributes']['data']['attributes']['payment_intent_id'];

    // Find the reservation associated with this paymentIntentID and update the payment status
    $sqlUpdatePayment = "UPDATE reservations SET paymentStatus = 'completed' WHERE paymentIntentID = :paymentIntentID";
    $stmtUpdate = $pdo->prepare($sqlUpdatePayment);
    $stmtUpdate->bindParam(':paymentIntentID', $paymentIntentID);

    // Execute the update query
    if ($stmtUpdate->execute()) {
        http_response_code(200); // Send success response to PayMongo
        echo 'Payment status updated successfully.';
    } else {
        http_response_code(500); // Internal Server Error for failed DB update
        echo 'Failed to update payment status in the database.';
    }
} else {
    http_response_code(400); // Bad Request if the event is not payment-related
    echo 'Invalid event type.';
}
?>
