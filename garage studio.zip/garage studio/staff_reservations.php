<?php
session_start();
require_once 'connection_cust.php';

// Check if the staff is logged in
if (!isset($_SESSION['staffID'])) {
    header('Location: staff_login.php'); // Redirect to staff login if not logged in
    exit();
}

// Handle accept or reject actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $reservationID = $_POST['reservationID'];
    $action = $_POST['action'];

    $status = ($action == 'accept') ? 'accepted' : 'rejected';

    try {
        // Update the reservation status in the database
        $sql = "UPDATE reservations SET reservationStatus = :status WHERE reservationID = :reservationID";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':reservationID', $reservationID);

        if ($stmt->execute()) {
            echo '<script>alert("Reservation has been '.$status.' successfully."); window.location.href = "staff_reservations.php";</script>';
        } else {
            echo '<div class="alert alert-danger">Failed to update reservation. Please try again.</div>';
        }
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}

// Fetch pending reservations
$sql = "SELECT r.reservationID, r.reservationDate, r.reservationTime, u.uFName, u.uLName, r.totalCost
        FROM reservations r
        JOIN users u ON r.userID = u.uUserID
        WHERE r.reservationStatus = 'pending'";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$pendingReservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reservations</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Pending Reservations</h2>

        <?php if (count($pendingReservations) > 0): ?>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                        <th>Reservation ID</th>
                        <th>User Name</th>
                        <th>Reservation Date</th>
                        <th>Reservation Time</th>
                        <th>Total Cost</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pendingReservations as $reservation): ?>
                        <tr>
                            <td><?php echo $reservation['reservationID']; ?></td>
                            <td><?php echo $reservation['uFName'] . ' ' . $reservation['uLName']; ?></td>
                            <td><?php echo $reservation['reservationDate']; ?></td>
                            <td><?php echo $reservation['reservationTime']; ?></td>
                            <td><?php echo '$' . number_format($reservation['totalCost'], 2); ?></td>
                            <td>
                                <form action="staff_reservations.php" method="POST" class="d-inline">
                                    <input type="hidden" name="reservationID" value="<?php echo $reservation['reservationID']; ?>">
                                    <button type="submit" name="action" value="accept" class="btn btn-success">Accept</button>
                                    <button type="submit" name="action" value="reject" class="btn btn-danger">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="alert alert-info">No pending reservations at the moment.</p>
        <?php endif; ?>
    </div>
</body>
</html>
