<?php
// Autoload PHPMailer classes using Composer
require 'PHPMailer/PHPMailer/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

session_start();
require_once 'connection_cust.php'; // Include your database connection

// Check if user is logged in and has appropriate access level
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 3) {
    header('Location: page_login.php');
    exit();
}

// Handle accept/reject actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $reservationID = $_POST['reservationID'];
    $action = $_POST['action']; // 'accept' or 'reject'

    // Fetch user email and name
    $sqlUser = "SELECT reservations.uUserID, reservations.reservationDate, reservations.reservationTime, 
                       CONCAT(users.uFName, ' ', users.uLName) AS full_name, users.uEmail
                FROM reservations 
                JOIN users ON reservations.uUserID = users.uUserID 
                WHERE reservations.reservationID = :reservationID";
    $stmtUser = $pdo->prepare($sqlUser);
    $stmtUser->bindParam(':reservationID', $reservationID);
    $stmtUser->execute();
    $userData = $stmtUser->fetch(PDO::FETCH_ASSOC);

    if ($userData) {
        $userEmail = $userData['uEmail'];
        $userName = $userData['full_name'];
        $reservationDate = $userData['reservationDate'];
        $reservationTime = $userData['reservationTime'];

        if ($action == 'accept') {
            $sql = "UPDATE reservations SET reservationStatus = 'accepted' WHERE reservationID = :reservationID";
            $subject = "Reservation Accepted";
            $message = "Dear $userName, \n\nYour reservation for $reservationDate at $reservationTime has been accepted. Thank you!";
        } elseif ($action == 'reject') {
            $sql = "UPDATE reservations SET reservationStatus = 'rejected' WHERE reservationID = :reservationID";
            $subject = "Reservation Rejected";
            $message = "Dear $userName, \n\nWe regret to inform you that your reservation for $reservationDate at $reservationTime has been rejected. Please try another slot. send your E-wallet for a refund";
        }

        // Update the reservation status
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':reservationID', $reservationID);

        if ($stmt->execute()) {
            // Initialize PHPMailer
            $mail = new PHPMailer(true);
            try {
                // SMTP settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';            // Set the SMTP server to send through
                $mail->SMTPAuth   = true;
                $mail->Username   = 'zerovstore@gmail.com';      // Your Gmail email
                $mail->Password   = 'fxqe wqwy silt ysln';       // Your Gmail password or app password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                // Email content
                $mail->setFrom('GarageMusicStudio@gmail.com', 'Garage Admin');  // Change to your email
                $mail->addAddress($userEmail, $userName);                // Recipient's email and name
                $mail->isHTML(false);                                    // Set email format to plain text
                $mail->Subject = $subject;
                $mail->Body    = $message;

                $mail->send();
                echo '<div class="alert alert-success">Reservation successfully ' . $action . 'ed and email notification sent to the user.</div>';
            } catch (Exception $e) {
                echo '<div class="alert alert-warning">Reservation ' . $action . 'ed, but email could not be sent. Mailer Error: ' . $mail->ErrorInfo . '</div>';
            }

            // Log the action to the audituser table
            $audit_sql = "INSERT INTO audituser (aAction, aTimestamp, uUserID) VALUES (:action, CURRENT_TIMESTAMP, :uUserID)";
            $audit_stmt = $pdo->prepare($audit_sql);
            $audit_action = ucfirst($action) . "ed reservation ID: " . $reservationID;
            $audit_stmt->bindParam(':action', $audit_action);
            $audit_stmt->bindParam(':uUserID', $_SESSION['uUserID']); // Store the staff member's user ID who performed the action
            $audit_stmt->execute();
        } else {
            echo '<div class="alert alert-danger">Failed to update reservation status. Please try again.</div>';
        }
    } else {
        echo '<div class="alert alert-danger">Failed to retrieve user details. Please try again.</div>';
    }
}

// Fetch pending reservations with user names
try {
    $sql = "SELECT reservations.*, CONCAT(users.uFName, ' ', users.uLName) AS full_name 
            FROM reservations 
            JOIN users ON reservations.uUserID = users.uUserID 
            WHERE reservationStatus = 'pending'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $pendingReservations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage();
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pending Requests</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
        }
        .sidebar .sidebar-heading {
            padding: 20px;
            font-size: 1.5rem;
            text-align: center;
            font-weight: bold;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .sidebar ul li a:hover {
            background-color: #495057;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
        }
    </style>
    <script>
        // Function to confirm the action
        function confirmAction(action) {
            return confirm('Are you sure you want to ' + action + ' this reservation?');
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-heading">Staff Dashboard</div>
        <ul>
            <li><a href="page_staff.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="view_pending_requests.php"><i class="fas fa-clock"></i> Reservation Requests</a></li>
            <li><a href="view_instrument_requests.php"><i class="fas fa-clock"></i> Instruments Requests</a></li>
            <li><a href="view_pedals_requests.php"><i class="fas fa-clock"></i> Pedals Requests</a></li>
            <li><a href="view_accepted_requests.php"><i class="fas fa-check-circle"></i> Accepted Requests</a></li>
            <li><a href="view_Instruments_inventory.php"><i class="fas fa-guitar"></i> Instruments Inventory</a></li>
            <li><a href="view_pedals_inventory.php"><i class="fas fa-guitar"></i> Pedals Inventory</a></li>
        </ul>
        <form action="logout.php" method="POST" class="logout-btn">
            <button type="submit" name="logout" class="btn btn-danger btn-block"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </div>

    <div class="content">
        <h2 class="text-center">Pending Reservation Requests</h2>
        <?php if (count($pendingReservations) > 0): ?>
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Reservation ID</th>
                        <th>User Name</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Total Cost</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pendingReservations as $reservation): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($reservation['reservationID']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['full_name']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['reservationDate']); ?></td>
                            <td>
                                <?php 
                                // Convert time to AM/PM format
                                $time = new DateTime($reservation['reservationTime']);
                                echo $time->format('h:i A'); // Format as h:i AM/PM
                                ?>
                            </td>
                            <td>₱<?php echo number_format($reservation['totalCost'], 2); ?></td>
                            <td>
                                <form method="POST" action="">
                                    <input type="hidden" name="reservationID" value="<?php echo $reservation['reservationID']; ?>">
                                    <!-- Confirm before accepting -->
                                    <button type="submit" name="action" value="accept" class="btn btn-success btn-sm" onclick="return confirmAction('accept');">Accept</button>
                                    <!-- Confirm before rejecting -->
                                    <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm" onclick="return confirmAction('reject');">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-info">No pending requests at this time.</div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
