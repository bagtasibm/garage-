<?php
session_start();
require 'vendor/autoload.php'; // Ensure Guzzle is correctly loaded

$secretKey = 'sk_test_RBzVXowV9LCedDFegJVkrZ7C'; // Replace with your PayMongo secret key

// Check if reservationID and totalCost are set in the session
if (!isset($_SESSION['reservationID']) || !isset($_SESSION['totalCost'])) {
    echo '<script>alert("No reservation found. Please try again."); window.location.href = "page_reservation.php";</script>';
    exit();
}

$reservationID = $_SESSION['reservationID'];
$totalCost = $_SESSION['totalCost']; // Total cost in pesos

// User details (auto-filled from session)
$userName = $_SESSION['user_fname'];
$userEmail = $_SESSION['uEmail'];
$userPhone = $_SESSION['uPhoneNumber'];

// Convert total cost to centavos (PayMongo uses centavos)
$amountInCentavos = $totalCost * 100;

$httpClient = new \GuzzleHttp\Client();

try {
    // Create the payment link in PayMongo
    $response = $httpClient->post('https://api.paymongo.com/v1/links', [
        'headers' => [
            'Authorization' => 'Basic ' . base64_encode($secretKey . ':'),  // Base64 encode secret key
            'Content-Type'  => 'application/json',
        ],
        'json' => [
            'data' => [
                'attributes' => [
                    'amount'      => $amountInCentavos,  // Amount in centavos
                    'description' => 'Payment for Garage Music Studio booking',
                    'remarks'     => 'Reservation #' . $reservationID . ' for recording session',
                    'customer'    => [
                        'name'  => $userName,
                        'email' => $userEmail,
                        'phone' => $userPhone
                    ],
                    'redirect'    => [
                        'success' => 'http://localhost/garage/customer_page.php',  // Redirect to homepage after payment success
                        'failed'  => 'http://localhost/garage/payment_failed.php'  // Redirect to error page if payment fails
                    ]
                ]
            ]
        ]
    ]);

    $responseBody = json_decode($response->getBody(), true);
    
    // Retrieve the PayMongo payment intent ID from the response
    $paymentIntentID = $responseBody['data']['id']; // PayMongo's payment intent ID

    // Store the paymentIntentID in the session to check later
    $_SESSION['paymentIntentID'] = $paymentIntentID;

    // Display a button for canceling the payment
    echo '<a href="page_reservation.php" class="btn btn-danger">Cancel Payment</a>';

    // Redirect the user to the payment link
    header('Location: ' . $responseBody['data']['attributes']['checkout_url']);
    exit();
} catch (Exception $e) {
    echo 'Error creating payment link: ' . $e->getMessage();
}
