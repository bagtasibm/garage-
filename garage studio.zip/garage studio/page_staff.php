<?php
session_start();
require_once 'connection_cust.php'; // Include your database connection

// Check if the user is logged in and has appropriate access level (assuming uLevel 3 is staff)
if (!isset($_SESSION['uUserID']) || $_SESSION['uLevel'] != 3) { 
    header('Location: page_login.php');
    exit();
}

// Initialize variables
$pendingCount = 0;
$acceptedCount = 0;
$totalUsers = 0;
$totalPayments = 0;
$pendingInstrumentsCount = 0;
$pendingPedalsCount = 0;
$totalInstrumentsInventory = 0;
$totalPedalsInventory = 0;

// Fetch necessary dashboard data
try {
    // Fetch pending reservations
    $sql = "SELECT COUNT(*) as pendingCount FROM reservations WHERE reservationStatus = 'pending'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $pendingCount = $stmt->fetch(PDO::FETCH_ASSOC)['pendingCount'];

    // Fetch accepted reservations
    $sql = "SELECT COUNT(*) as acceptedCount FROM reservations WHERE reservationStatus = 'accepted'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $acceptedCount = $stmt->fetch(PDO::FETCH_ASSOC)['acceptedCount'];

    // Fetch total users
    $sql = "SELECT COUNT(*) as totalUsers FROM users";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $totalUsers = $stmt->fetch(PDO::FETCH_ASSOC)['totalUsers'];

    // Fetch total payments for the current day
    $sqlPayments = "SELECT SUM(totalCost) as totalPayments 
                    FROM reservations 
                    WHERE (paymentStatus = 'completed' AND DATE(created_at) = CURDATE()) 
                    OR (reservationStatus = 'accepted' AND DATE(created_at) = CURDATE())"; // Adjusted condition
    $stmtPayments = $pdo->prepare($sqlPayments);
    $stmtPayments->execute();
    $totalPayments = $stmtPayments->fetch(PDO::FETCH_ASSOC)['totalPayments'] ?? 0;

    // Fetch pending instruments
    $sqlPendingInstruments = "SELECT COUNT(*) as pendingInstrumentsCount FROM user_instruments WHERE status = 'pending'";
    $stmtPendingInstruments = $pdo->prepare($sqlPendingInstruments);
    $stmtPendingInstruments->execute();
    $pendingInstrumentsCount = $stmtPendingInstruments->fetch(PDO::FETCH_ASSOC)['pendingInstrumentsCount'];

    // Fetch pending pedals
    $sqlPendingPedals = "SELECT COUNT(*) as pendingPedalsCount FROM user_pedals WHERE status = 'pending'";
    $stmtPendingPedals = $pdo->prepare($sqlPendingPedals);
    $stmtPendingPedals->execute();
    $pendingPedalsCount = $stmtPendingPedals->fetch(PDO::FETCH_ASSOC)['pendingPedalsCount'];

    // Fetch total instruments inventory
    $sqlTotalInstruments = "SELECT COUNT(*) as totalInstruments FROM instruments WHERE availability_status = 'available'";
    $stmtTotalInstruments = $pdo->prepare($sqlTotalInstruments);
    $stmtTotalInstruments->execute();
    $totalInstrumentsInventory = $stmtTotalInstruments->fetch(PDO::FETCH_ASSOC)['totalInstruments'];

    // Fetch total pedals inventory
    $sqlTotalPedals = "SELECT COUNT(*) as totalPedals FROM pedals WHERE availability_status = 'available'";
    $stmtTotalPedals = $pdo->prepare($sqlTotalPedals);
    $stmtTotalPedals->execute();
    $totalPedalsInventory = $stmtTotalPedals->fetch(PDO::FETCH_ASSOC)['totalPedals'];

} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            background-color: #f4f4f9;
            font-family: Arial, sans-serif;
        }
        .sidebar {
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding-top: 20px;
            position: fixed;
            width: 250px;
        }
        .sidebar .sidebar-heading {
            padding: 20px;
            font-size: 1.5rem;
            text-align: center;
            font-weight: bold;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 10px 0;
        }
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .sidebar ul li a:hover {
            background-color: #495057;
        }
        .content {
            margin-left: 270px;
            padding: 20px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        .dashboard-item {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        .dashboard-item h2 {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .dashboard-item p {
            color: #6c757d;
        }
        .dashboard-item .icon {
            font-size: 3rem;
            margin-bottom: 15px;
        }
        .yellow { color: #ffc107; }
        .green { color: #28a745; }
        .red { color: #dc3545; }
        .blue { color: #007bff; }
        .logout-btn {
            position: fixed;
            bottom: 20px;
            width: 200px;
            margin-left: 20px;
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <div class="sidebar-heading">Staff Dashboard</div>
        <ul>
            <li><a href="page_staff.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li><a href="view_pending_requests.php"><i class="fas fa-clock"></i> Reservation Requests</a></li>
            <li><a href="view_instrument_requests.php"><i class="fas fa-clock"></i> Instruments Requests</a></li>
            <li><a href="view_pedals_requests.php"><i class="fas fa-clock"></i> Pedals Requests</a></li>
            <li><a href="view_accepted_requests.php"><i class="fas fa-check-circle"></i> Accepted Requests</a></li>
            <li><a href="view_Instruments_inventory.php"><i class="fas fa-guitar"></i> Instruments Inventory</a></li>
            <li><a href="view_pedals_inventory.php"><i class="fas fa-guitar"></i> Pedals Inventory</a></li>
        </ul>
        <form action="logout.php" method="POST" class="logout-btn">
            <button type="submit" name="logout" class="btn btn-danger btn-block"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </div>

    <div class="content">
        <h1 class="mb-4">Welcome, Staff Member</h1>
        <div class="dashboard-grid">
            <div class="dashboard-item">
                <div class="icon yellow"><i class="fas fa-clock"></i></div>
                <h2><?php echo $pendingCount; ?></h2>
                <p>Pending Reservations</p>
            </div>
            <div class="dashboard-item">
                <div class="icon green"><i class="fas fa-check-circle"></i></div>
                <h2><?php echo $acceptedCount; ?></h2>
                <p>Accepted Reservations</p>
            </div>
            <div class="dashboard-item">
                <div class="icon yellow"><i class="fas fa-clock"></i></div>
                <h2><?php echo $pendingInstrumentsCount; ?></h2>
                <p>Pending Instruments</p>
            </div>
            <div class="dashboard-item">
                <div class="icon yellow"><i class="fas fa-clock"></i></div>
                <h2><?php echo $pendingPedalsCount; ?></h2>
                <p>Pending Pedals</p>
            </div>
            <div class="dashboard-item">
                <div class="icon blue"><i class="fas fa-guitar"></i></div>
                <h2><?php echo $totalInstrumentsInventory; ?></h2>
                <p>Total Instruments Inventory</p>
            </div>
            <div class="dashboard-item">
                <div class="icon blue"><i class="fas fa-guitar"></i></div>
                <h2><?php echo $totalPedalsInventory; ?></h2>
                <p>Total Pedals Inventory</p>
            </div>
            <div class="dashboard-item">
                <div class="icon green"><i class="fas fa-money-bill-wave"></i></div>
                <h2>₱<?php echo number_format($totalPayments, 2); ?></h2>
                <p>Total Payments Today</p>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>
